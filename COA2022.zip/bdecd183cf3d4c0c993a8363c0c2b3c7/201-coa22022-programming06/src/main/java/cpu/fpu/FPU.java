package cpu.fpu;

import util.DataType;
import util.IEEE754Float;

import java.util.Objects;

import cpu.alu.ALU;

import static util.IEEE754Float.*;
import static util.IEEE754Float.N_INF;
import static util.Transformer.binaryToInt;
import static util.Transformer.intToBinary;

/**
 * floating point unit
 * 执行浮点运算的抽象单元
 * 浮点数精度：使用3位保护位进行计算
 */
public class FPU {

    private final String[][] mulCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.P_ZERO, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_ZERO, IEEE754Float.NaN}
    };

    private final String[][] divCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
    };

    //
//    return s+d
    public String myadd(String s, String d) {
        String a = new String("");
        int flag = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            if (s.charAt(i) == '1' && d.charAt(i) == '1' && flag == 1) {
                a = "1" + a;
                flag = 1;
            } else if (s.charAt(i) == '1' && d.charAt(i) == '1' && flag == 0) {
                a = "0" + a;
                flag = 1;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '1' && flag == 1 ||
                    s.charAt(i) == '1' && d.charAt(i) == '0' && flag == 1) {
                a = "0" + a;
                flag = 1;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '1' && flag == 0 ||
                    s.charAt(i) == '1' && d.charAt(i) == '0' && flag == 0) {
                a = "1" + a;
                flag = 0;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '0' && flag == 0) {
                a = "0" + a;
                flag = 0;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '0' && flag == 1) {
                a = "1" + a;
                flag = 0;
            }
        }
//        System.out.println(a);
        if (flag == 1)
            return "1" + a;
        else
            return "0" + a;
    }

    //    return d*s
//    d为被乘数 不变 s为乘数
//    1101 1011
//    1000 1111
    public String mymul(String s, String d) {
        StringBuilder dtmp = new StringBuilder("0");
        for (int i = 0; i < d.length(); i++) {
            dtmp.append("0");
        }
        StringBuilder a = new StringBuilder(dtmp.toString());
//        System.out.println(a.toString());
        for (int i = 1; i <= s.length(); i++) {
            if (s.charAt(s.length() - i) == '1') {
                StringBuilder tmp = new StringBuilder(a.substring(1, d.length() + 1));
                tmp = new StringBuilder(myadd(tmp.toString(), d));
                a.replace(0, d.length() + 1, tmp.toString());
            }
//            System.out.println(a.toString());
            a.insert(0, "0");
//            System.out.println(a.toString());
        }
        return a.substring(1, a.length());
    }

    //    d/s = ans 不要余数 54/27
    public String mydiv(String d, String s) {
        s = "00000" + s;
        String ns = binaryToInt(s);
        int t = -Integer.parseInt(ns);
        ns = intToBinary(String.valueOf(t));
        ns = "111111111111111111111111111" + ns;
//        System.out.println(ns);
        StringBuilder A = new StringBuilder("000000000000000000000000000000000000000000000000000000" + d
                + "000000000000000000000000000");
        StringBuilder M = new StringBuilder(ns);
        for (int i = 0; i < 54; i++) {
            A.delete(0, 1);
            StringBuilder tmp = new StringBuilder(myadd(A.substring(0, 54), M.toString()));
            if (tmp.charAt(0) == '0') {
//                不够减
                A.append("0");
            } else {
                A.append("1");
                A.replace(0, 54, tmp.toString().substring(1));
            }
        }
        return A.toString();
    }

    /**
     * compute the float mul of dest * src
     */
    public DataType mul(DataType src, DataType dest) {
        String s = src.toString();
        String d = dest.toString();
//        NaN
        if (s.matches(IEEE754Float.NaN_Regular) || d.matches(IEEE754Float.NaN_Regular)) {
            return new DataType(IEEE754Float.NaN);
        }
//        0 or inf
        if (cornerCheck(mulCorner, d, s) != null) {
            return new DataType(Objects.requireNonNull(cornerCheck(mulCorner, d, s)));
        }
//        one of the op is zero
        if (d.equals(IEEE754Float.P_ZERO)) {
            return (s.charAt(0) == '0') ? new DataType(IEEE754Float.P_ZERO) : new DataType(IEEE754Float.N_ZERO);
        } else if (d.equals(IEEE754Float.N_ZERO)) {
            return (s.charAt(0) == '1') ? new DataType(IEEE754Float.P_ZERO) : new DataType(IEEE754Float.N_ZERO);
        }
        if (s.equals(IEEE754Float.P_ZERO)) {
            return (d.charAt(0) == '0') ? new DataType(IEEE754Float.P_ZERO) : new DataType(IEEE754Float.N_ZERO);
        } else if (s.equals(IEEE754Float.N_ZERO)) {
            return (d.charAt(0) == '1') ? new DataType(IEEE754Float.P_ZERO) : new DataType(IEEE754Float.N_ZERO);
        }
//        one of the op is Inf
        if (d.equals(P_INF)) {
            return (s.charAt(0) == '0') ? new DataType(P_INF) : new DataType(N_INF);
        } else if (d.equals(N_INF)) {
            return (s.charAt(0) == '1') ? new DataType(P_INF) : new DataType(N_INF);
        }
        if (s.equals(P_INF)) {
            return (d.charAt(0) == '0') ? new DataType(P_INF) : new DataType(N_INF);
        } else if (s.equals(N_INF)) {
            return (d.charAt(0) == '1') ? new DataType(P_INF) : new DataType(N_INF);
        }

        String s_neg = s.substring(0, 1);
        String s_e = s.substring(1, 9);
        String s_f = s.substring(9, 32);
        String d_neg = d.substring(0, 1);
        String d_e = d.substring(1, 9);
        String d_f = d.substring(9, 32);

        if (Objects.equals(s_e, "00000000")) {
            s_f = "0" + s_f + "000";
            s_e = "00000001";
        } else {
            s_f = "1" + s_f + "000";
        }
        if (Objects.equals(d_e, "00000000")) {
            d_f = "0" + d_f + "000";
            d_e = "00000001";
        } else {
            d_f = "1" + d_f + "000";
        }

//        System.out.println("src:" + src.toString());
//        System.out.println("src_e:" + s_e);
//        System.out.println("src_e:" + binaryToInt(s_e));
//        System.out.println("src_f:" + s_f);
//        System.out.println("dest:" + dest.toString());
//        System.out.println("dest_e:" + d_e);
//        System.out.println("dest_e:" + binaryToInt(d_e));
//        System.out.println("dest_f:" + s_f);

//      符号位
        String ans_neg = (s_neg.equals(d_neg)) ? "0" : "1";

//      指数位
        int ei = Integer.parseInt(binaryToInt(s_e)) + Integer.parseInt(binaryToInt(d_e)) - 127 + 1;
//        System.out.println(ei);

        StringBuilder ans_f = new StringBuilder(mymul(s_f, d_f));
//        System.out.println(ans_f);

        while (ans_f.charAt(0) == '0' && ei > 0) {
            ans_f.append('0');
            ans_f.delete(0, 1);
            ei -= 1;
        }

        while (ei < 0) {
            int flag = 0;
//            如果全为0，break
            for (int i = 0; i < 27; i++) {
                if (ans_f.charAt(i) == '1') {
                    flag = 1;
                }
            }
            if (flag == 0) {
                break;
            } else {
                ans_f.insert(0, '0');
                ans_f.delete(ans_f.length() - 1, ans_f.length());
                ei += 1;
            }
        }


        String ans_e = intToBinary(String.valueOf(ei)).substring(24);
        if (ei == 0) {
//            阶码为0
            ans_f.insert(0, 0);
            ans_f.delete(ans_f.length() - 1, ans_f.length());
            return new DataType(round(ans_neg.charAt(0), ans_e, ans_f.toString()));
        } else if (ei < 0) {
//            阶码下溢
            return new DataType(ans_neg.charAt(0) == '0' ? P_ZERO : N_ZERO);
        } else if (ei >= 255) {
//            阶码上溢
            return new DataType(ans_neg.charAt(0) == '0' ? P_INF : N_INF);
        } else {
            return new DataType(round(ans_neg.charAt(0), ans_e, ans_f.toString()));
        }

    }


    /**
     * compute the float mul of dest / src
     */
    public DataType div(DataType src, DataType dest) {
        String s = src.toString();
        String d = dest.toString();
//        NaN
        if (s.matches(IEEE754Float.NaN_Regular) || d.matches(IEEE754Float.NaN_Regular)) {
            return new DataType(IEEE754Float.NaN);
        }
//        0 or inf
        if (cornerCheck(divCorner, d, s) != null) {
            return new DataType(Objects.requireNonNull(cornerCheck(divCorner, d, s)));
        }
//        0/x
        if (d.equals(IEEE754Float.P_ZERO)) {
            return (s.charAt(0) == '0') ? new DataType(IEEE754Float.P_ZERO) : new DataType(IEEE754Float.N_ZERO);
        } else if (d.equals(IEEE754Float.N_ZERO)) {
            return (s.charAt(0) == '1') ? new DataType(IEEE754Float.P_ZERO) : new DataType(IEEE754Float.N_ZERO);
        }
//        x/0
        if (s.equals(IEEE754Float.P_ZERO)) {
            throw new ArithmeticException();
        } else if (s.equals(IEEE754Float.N_ZERO)) {
            throw new ArithmeticException();
        }
//        Inf/s
        if (d.equals(P_INF)) {
            return (s.charAt(0) == '0') ? new DataType(P_INF) : new DataType(N_INF);
        } else if (d.equals(N_INF)) {
            return (s.charAt(0) == '1') ? new DataType(P_INF) : new DataType(N_INF);
        }
//        d/inf
        if (s.equals(P_INF) || s.equals(N_INF)) {
            return (d.charAt(0) == '0') ? new DataType(P_ZERO) : new DataType(N_ZERO);
        }

        String s_neg = s.substring(0, 1);
        String s_e = s.substring(1, 9);
        String s_f = s.substring(9, 32);
        String d_neg = d.substring(0, 1);
        String d_e = d.substring(1, 9);
        String d_f = d.substring(9, 32);

        if (Objects.equals(s_e, "00000000")) {
            s_f = "0" + s_f + "000";
            s_e = "00000001";
        } else {
            s_f = "1" + s_f + "000";
        }
        if (Objects.equals(d_e, "00000000")) {
            d_f = "0" + d_f + "000";
            d_e = "00000001";
        } else {
            d_f = "1" + d_f + "000";
        }

//        System.out.println("dest_e:" + binaryToInt(d_e));
//        System.out.println("dest_f:" + d_f);
//        System.out.println("src_e:" + binaryToInt(s_e));
//        System.out.println("src_f:" + s_f);
//        d/s
//      符号位
        String ans_neg = (s_neg.equals(d_neg)) ? "0" : "1";

//      指数位
        int ei = -Integer.parseInt(binaryToInt(s_e)) + Integer.parseInt(binaryToInt(d_e)) + 127;

        StringBuilder ans_f = new StringBuilder(mydiv(d_f, s_f));
        String ans_e = intToBinary(String.valueOf(ei)).substring(24);
        ans_f = new StringBuilder(ans_f.substring(75,102));
        if (ei == 0) {
//            阶码为0
            ans_f.insert(0, 0);
            ans_f.delete(ans_f.length() - 1, ans_f.length());
            return new DataType(round(ans_neg.charAt(0), ans_e, ans_f.toString()));
        } else if (ei < 0) {
//            阶码下溢
            return new DataType(ans_neg.charAt(0) == '0' ? P_ZERO : N_ZERO);
        } else if (ei >= 255) {
//            阶码上溢
            return new DataType(ans_neg.charAt(0) == '0' ? P_INF : N_INF);
        } else {
            return new DataType(round(ans_neg.charAt(0), ans_e,
                    ans_f.toString()));
        }
    }


    private String cornerCheck(String[][] cornerMatrix, String oprA, String oprB) {
        for (String[] matrix : cornerMatrix) {
            if (oprA.equals(matrix[0]) &&
                    oprB.equals(matrix[1])) {
                return matrix[2];
            }
        }
        return null;
    }

    /**
     * right shift a num without considering its sign using its string format
     *
     * @param operand to be moved
     * @param n       moving nums of bits
     * @return after moving
     */
    private String rightShift(String operand, int n) {
        StringBuilder result = new StringBuilder(operand);  //保证位数不变
        boolean sticky = false;
        for (int i = 0; i < n; i++) {
            sticky = sticky || result.toString().endsWith("1");
            result.insert(0, "0");
            result.deleteCharAt(result.length() - 1);
        }
        if (sticky) {
            result.replace(operand.length() - 1, operand.length(), "1");
        }
        return result.substring(0, operand.length());
    }

    /**
     * 对GRS保护位进行舍入
     *
     * @param sign    符号位
     * @param exp     阶码
     * @param sig_grs 带隐藏位和保护位的尾数
     * @return 舍入后的结果
     */
    private String round(char sign, String exp, String sig_grs) {
        int grs = Integer.parseInt(sig_grs.substring(24, 27), 2);
        if ((sig_grs.substring(27).contains("1")) && (grs % 2 == 0)) {
            grs++;
        }
        String sig = sig_grs.substring(0, 24); // 隐藏位+23位
        if (grs > 4 || (grs == 4 && sig.endsWith("1"))) {
            sig = oneAdder(sig);
            if (sig.charAt(0) == '1') {
                exp = oneAdder(exp).substring(1);
                sig = sig.substring(1);
            }
        }

        if (Integer.parseInt(sig.substring(0, sig.length() - 23), 2) > 1) {
            sig = rightShift(sig, 1);
            exp = oneAdder(exp).substring(1);
        }
        if (exp.equals("11111111")) {
            return sign == '0' ? IEEE754Float.P_INF : IEEE754Float.N_INF;
        }

        return sign + exp + sig.substring(sig.length() - 23);
    }

    /**
     * add one to the operand
     *
     * @param operand the operand
     * @return result after adding, the first position means overflow (not equal to the carray to the next) and the remains means the result
     */
    private String oneAdder(String operand) {
        int len = operand.length();
        StringBuffer temp = new StringBuffer(operand);
        temp = temp.reverse();
        int[] num = new int[len];
        for (int i = 0; i < len; i++) num[i] = temp.charAt(i) - '0';  //先转化为反转后对应的int数组
        int bit = 0x0;
        int carry = 0x1;
        char[] res = new char[len];
        for (int i = 0; i < len; i++) {
            bit = num[i] ^ carry;
            carry = num[i] & carry;
            res[i] = (char) ('0' + bit);  //显示转化为char
        }
        String result = new StringBuffer(new String(res)).reverse().toString();
        return "" + (result.charAt(0) == operand.charAt(0) ? '0' : '1') + result;  //注意有进位不等于溢出，溢出要另外判断
    }

}
