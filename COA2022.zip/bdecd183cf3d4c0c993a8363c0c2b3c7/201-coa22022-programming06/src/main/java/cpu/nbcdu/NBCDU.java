package cpu.nbcdu;

import util.DataType;

public class NBCDU {

    //    10:01010
//    -10:10110
//    >=10:return 1
    public int myjudge(String x) {
        String t = "01010";
        for (int i = 0; i < 5; i++) {
            if (x.charAt(i) == t.charAt(i)) {
                continue;
            } else if (x.charAt(i) == '1' && t.charAt(i) == '0') {
                return 1;
            } else if (x.charAt(i) == '0' && t.charAt(i) == '1') {
                return 0;
            }
        }
        return 1;
    }

    //    x>y return1
//    x<y return0
//    x==y return 2
    public int myjudge(String x, String y) {
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) == y.charAt(i)) {
            } else if (x.charAt(i) == '1' && y.charAt(i) == '0') {
                return 1;
            } else if (x.charAt(i) == '0' && y.charAt(i) == '1') {
                return 0;
            }
        }
        return 2;
    }

    public String myrev(String x) {
//        1001 0101 0010 5+（-2）1110 0011
        StringBuilder nx = new StringBuilder("");
        for (int i = 0; i < x.length(); i++) {
            if (x.charAt(i) == '0') {
                nx.append('1');
            } else {
                nx.append('0');
            }
        }
        nx = new StringBuilder(myadd(nx.toString(), "0001").substring(1));
        return myadd("1001", nx.toString()).substring(1);
    }

    public String myadd(String s, String d) {
        String a = new String("");
        int flag = 0;
        for (int i = s.length() - 1; i >= 0; i--) {
            if (s.charAt(i) == '1' && d.charAt(i) == '1' && flag == 1) {
                a = "1" + a;
                flag = 1;
            } else if (s.charAt(i) == '1' && d.charAt(i) == '1' && flag == 0) {
                a = "0" + a;
                flag = 1;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '1' && flag == 1 ||
                    s.charAt(i) == '1' && d.charAt(i) == '0' && flag == 1) {
                a = "0" + a;
                flag = 1;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '1' && flag == 0 ||
                    s.charAt(i) == '1' && d.charAt(i) == '0' && flag == 0) {
                a = "1" + a;
                flag = 0;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '0' && flag == 0) {
                a = "0" + a;
                flag = 0;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '0' && flag == 1) {
                a = "1" + a;
                flag = 0;
            }
        }
//        System.out.println(a);
        if (flag == 1)
            return "1" + a;
        else
            return "0" + a;
    }

    /**
     * @param src  A 32-bits NBCD String
     * @param dest A 32-bits NBCD String
     * @return dest + src
     */
    DataType add(DataType src, DataType dest) {
//        同号加法
        int c = 0;
        StringBuilder ans = new StringBuilder("");
        String s = src.toString();
        String d = dest.toString();
        if (s.substring(0, 4).equals(d.substring(0, 4))) {
            for (int i = 1; i <= 7; i++) {
                StringBuilder t = new StringBuilder(myadd(s.substring(32 - 4 * i, 36 - 4 * i)
                        , d.substring(32 - 4 * i, 36 - 4 * i)));
                if (c == 1)
                    t = new StringBuilder(myadd(t.toString(), "00001").substring(1));
                if (myjudge(t.toString()) == 1) {
//             大于10
                    t = new StringBuilder(myadd(t.toString(), "10110").substring(1));
                    ans.insert(0, t.substring(1));
                    c = 1;
                } else if (myjudge(t.toString()) == 0) {
                    ans.insert(0, t.substring(1));
                    c = 0;
                }
            }
            ans.insert(0, s.substring(0, 4));
//        System.out.println(ans);
            return new DataType(ans.toString());
        } else {
            int tag = myjudge(d.substring(4), s.substring(4));
            if (tag == 1) {
//                d比较大
                StringBuilder ns = new StringBuilder("");
                for (int i = 1; i <= 7; i++) {
                    ns.insert(0, myrev(s.substring(32 - 4 * i, 36 - 4 * i)));
                }
                ns.insert(0, d.substring(0, 4));
                ns = new StringBuilder(add(new DataType(ns.toString()),
                        new DataType(ns.substring(0, 4) + "0000000000000000000000000001")).toString());
                ans = new StringBuilder(add(new DataType(ns.toString()), new DataType(d)).toString());
                return new DataType(ans.toString());
            } else if (tag == 0) {
//                s比较大
                StringBuilder nd = new StringBuilder("");
                for (int i = 1; i <= 7; i++) {
                    nd.insert(0, myrev(d.substring(32 - 4 * i, 36 - 4 * i)));
                }
                nd.insert(0, s.substring(0, 4));
                nd = new StringBuilder(add(new DataType(nd.toString()),
                        new DataType(nd.substring(0, 4) + "0000000000000000000000000001")).toString());
                ans = new StringBuilder(add(new DataType(nd.toString()), new DataType(s)).toString());
                return new DataType(ans.toString());
            } else {
//                符号相反，大小相同
                return new DataType("11000000000000000000000000000000");
            }
        }
    }

    /***
     *
     * @param src A 32-bits NBCD String
     * @param dest A 32-bits NBCD String
     * @return dest - src
     */
    DataType sub(DataType src, DataType dest) {
        int c = 0;
        StringBuilder ans = new StringBuilder("");
        String s = src.toString();
        String d = dest.toString();
        StringBuilder ns = new StringBuilder("");
        ns = new StringBuilder(s.startsWith("1100")?"1101":"1100");
        return add(new DataType(ns.toString()), dest);
    }

}
