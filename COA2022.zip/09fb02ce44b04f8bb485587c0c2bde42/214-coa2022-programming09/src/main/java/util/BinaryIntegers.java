package util;

/**
 * 存放32位二进制整数
 */
public class BinaryIntegers {

    public static final String ZERO = "00000000000000000000000000000000";

    public static final String NegativeOne = "11111111111111111111111111111111";

}
