package memory.cache.cacheReplacementStrategy;

import memory.Memory;
import memory.cache.Cache;

/**
 * TODO 最近不经常使用算法
 */
public class LFUReplacement implements ReplacementStrategy {

    @Override
    public void hit(int rowNO) {
        Cache.getCache().addVisited(rowNO);
    }

    @Override
    public int replace(int start, int end, char[] addrTag, byte[] input) {
//        从0次开始遍历，找到第一个命中次数最少的，假设所有行命中次数都不超过100
        int linenum = 0;
        for (int count = 0; count < 500; count++) {
            for (int line = start; line <= end; line++) {
                if (Cache.getCache().getVisited(line) == count){
                    if(Cache.getCache().isDirty(line)&& Cache.getCache().isValid(line)){
                        Memory.getMemory().write(Cache.getCache().getpAddr(line), 64, Cache.getCache().getData(line));
                        Cache.getCache().setDirty(line);
                    }
                    Cache.getCache().update(line, addrTag, input);
                    Cache.getCache().setVisited(line);
                    linenum = line;
                }
            }
        }
        return linenum;
    }

}
