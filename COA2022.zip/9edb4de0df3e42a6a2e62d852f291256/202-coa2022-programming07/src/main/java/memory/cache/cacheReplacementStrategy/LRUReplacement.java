package memory.cache.cacheReplacementStrategy;

import memory.Memory;
import memory.cache.Cache;

/**
 * TODO 最近最少用算法
 */
public class LRUReplacement implements ReplacementStrategy {

    private static long time = 0L;

    @Override
    public void hit(int rowNO) {
//        除了命中行 其他行(有效)
        time += 1;
        Cache.getCache().setTimeStampLRU(rowNO, time);
    }

    @Override
    public int replace(int start, int end, char[] addrTag, byte[] input) {
//        在替换范围中找一个最小值替换，其值变成最大值加一，其他值不变
        long longestRow = 1L << 30;
        int line = -1;
        for (int i = start; i <= end; i++) {
            long Row = Cache.getCache().getTimeStamp(i);
            if (Row < longestRow) {
                longestRow = Row;
                line = i;
            }
        }
        if(Cache.getCache().isDirty(line) && Cache.getCache().isValid(line)){
            Memory.getMemory().write(Cache.getCache().getpAddr(line), 64, Cache.getCache().getData(line));
            Cache.getCache().setDirty(line);
        }
        Cache.getCache().update(line, addrTag, input);
        time += 1;
        Cache.getCache().setTimeStampLRU(line, time);
        return line;
    }
}





























