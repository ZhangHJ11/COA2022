package cpu.alu;

import util.DataType;

import java.util.Objects;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 */
public class ALU {

    DataType remainderReg;

    /**
     * 返回两个二进制整数的除法结果
     * dest ÷ src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public DataType div(DataType src, DataType dest) {
        String s = src.toString();
        String d = dest.toString();
        String quo="";
        if (Objects.equals(s, "00000000000000000000000000000000")) throw new ArithmeticException();
        if (Objects.equals(d, "00000000000000000000000000000000")) {
            remainderReg = dest;
            return dest;
        }
        StringBuilder pro = new StringBuilder(d);
        for(int i=0;i<32;i++) pro.insert(0,d.charAt(0));
        if(pro.charAt(0)==s.charAt(0))
            pro = new StringBuilder(sub(s, pro.substring(0, pro.length() / 2)) + pro.substring(pro.length() / 2));
        else
            pro = new StringBuilder(add(s, pro.substring(0, pro.length() / 2)) + pro.substring(pro.length() / 2));
        for(int i=0;i<32;i++){
            if(pro.charAt(0)==s.charAt(0)){
                quo+='1';
                pro = new StringBuilder(pro.substring(1) + '0');
                pro = new StringBuilder(sub(s, pro.substring(0, pro.length() / 2)) + pro.substring(pro.length() / 2));
            } else {
                quo+='0';
                pro = new StringBuilder(pro.substring(1) + '0');
                pro = new StringBuilder(add(s, pro.substring(0, pro.length() / 2)) + pro.substring(pro.length() / 2));
            }
        }

        quo = quo.substring(1);
        if(pro.charAt(0)==s.charAt(0)) quo += '1';
        else quo += '0';
        if(quo.charAt(0) == '1') quo = add(quo,"00000000000000000000000000000001");

        String reminder = pro.substring(0,pro.length()/2);
        if(d.charAt(0) != pro.charAt(0)){
            if(quo.charAt(0) == '1') reminder = sub(s,reminder);
            else reminder = add(s,reminder);
        }

        if(reminder.equals(s)){
            quo = add(quo,"00000000000000000000000000000001");
            reminder = "000000000000000000000000000000000";
            remainderReg = new DataType(reminder);
            return new DataType(quo);
        }else if(Objects.equals(add(reminder, s), "00000000000000000000000000000000")){
            quo = sub("00000000000000000000000000000001",quo);
            reminder = "00000000000000000000000000000000";
            remainderReg = new DataType(reminder);
            return new DataType(quo);
        }

        remainderReg = new DataType(reminder);
        return new DataType(quo);
    }

    /**
     * 返回两个二进制整数的和
     * dest + src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public String add(String src, String dest) {
        int c=0;
        int s1,d1;
        String s = src.toString();
        String d = dest.toString();
        StringBuilder ans = new StringBuilder();
        for(int i=s.length()-1;i>=0;i--){
            s1 = s.charAt(i) - '0';
            d1 = d.charAt(i) - '0';
            ans.append(c ^ s1 ^ d1);
            c = (s1 & d1) | (c & d1) | (s1 & c);
        }
        return ans.reverse().toString();
    }

    /**
     * 返回两个二进制整数的差
     * dest - src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public String sub(String src, String dest) {
        int c=1;
        int s1,d1;
        String s = src.toString();
        String d = dest.toString();
        StringBuilder ans = new StringBuilder();
        for(int i=s.length()-1;i>=0;i--){
            s1 = 1 - (s.charAt(i) - '0');
            d1 = d.charAt(i) - '0';
            ans.append(c ^ s1 ^ d1);
            c = (s1 & d1) | (c & d1) | (s1 & c);

        }
        return ans.reverse().toString();
    }
}
