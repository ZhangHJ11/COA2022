import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import transformer.Transformer;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.Arrays;
import java.util.Random;

import static org.junit.Assert.*;

public class MMUTest {

    Memory memory = Memory.getMemory();
    MMU mmu = MMU.getMMU();
    Disk disk = Disk.getDisk();

    Transformer t = new Transformer();

    InputStream in = null;
    PrintStream out = null;
    PrintStream err = null;
    InputStream inputStream = null;
    OutputStream outputStream = null;


    @Before
    public void setUp() {
        in = System.in;
        out = System.out;
        err = System.err;
        Memory.SEGMENT_REPLACE = true;
        outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        System.setErr(new PrintStream(outputStream));
    }


    @After
    public void tearDown() {
        System.setIn(in);
        System.setOut(out);
        System.setErr(err);
        memory.clear();
    }

    // normal test 3 read 2 write

    @Test
    public void testA() {
        String eip = "00000000000000000000000000000000";
        int len = 1024 * 1024;
        char[] expect = fillData((char) 0b00001111, len);
        disk.write(eip, len, expect);
        memory.alloc_seg_force(0, eip, len, false, eip);
        memory.seg_load(0);
        assertArrayEquals(expect, mmu.read("000000000000000000000000000000000000000000000000", len).get(0).toCharArray());
    }

    @Test
    public void testB() {
        int len = new Random().nextInt(1024 * 1024 * 5);
        String memory_eip = t.intToBinary(String.valueOf(new Random().nextInt(1024 * 1024 * 16 - len)));
        String disk_eip = t.intToBinary(String.valueOf(new Random().nextInt(1024 * 1024 * 64 - len)));
        char[] expect = fillData((char) 0b11101010, len);
        disk.write(disk_eip, len, expect);
        memory.alloc_seg_force(0, memory_eip, len, false, disk_eip);
        memory.seg_load(0);
        assertArrayEquals(expect, mmu.read("000000000000000000000000000000000000000000000000", len).get(0).toCharArray());
    }

    @Test
    public void testC() {
        String memory_eip = "00000000101101001001110000100111";
        String disk_eip = "00000010000001010011011101001001";
        int len = 1696060;
        int offset = 774620;
        String read_eip = "00000000000010111101000111011100";
        char[] expect = fillData((char) 0b10000010, len);
        memory.alloc_seg_force(0, memory_eip, len, false, disk_eip);
        disk.write(disk_eip, len, expect);
        memory.seg_load(0);
        assertArrayEquals(Arrays.copyOfRange(expect, offset, expect.length), mmu.read("0000000000000000" + read_eip, len - offset).get(0).toCharArray());
    }


    @Test
    public void testD() {
        String memory_eip = "00000000011010001010101001101001";
        String disk_eip = "00000010010110100000010000010010";
        int len = 469043;
        int offset = 413486;
        String read_eip = "00000000000001100100111100101110";
        char[] expect = fillData((char) 0b01101101, len);
        memory.alloc_seg_force(0, memory_eip, len, false, disk_eip);
        memory.seg_load(0);
        mmu.write("0000000000000000" + read_eip, len - offset, Arrays.copyOfRange(expect, offset, expect.length));
        assertArrayEquals(Arrays.copyOfRange(expect, offset, expect.length), mmu.read("0000000000000000" + read_eip, len - offset).get(0).toCharArray());
    }

    @Test
    public void testE() {
        String memory_eip = "00000000010000001011000100110101";
        String disk_eip = "00000011000001000101111011101001";
        int len = 3836672;
        int offset = 659758;
        String read_eip = "00000000000010100001000100101110";
        char[] expect = fillData((char) 0b01010011, len);
        memory.alloc_seg_force(0, memory_eip, len, false, disk_eip);
        memory.seg_load(0);
        mmu.write("0000000000000000" + read_eip, len - offset, Arrays.copyOfRange(expect, offset, expect.length));
        assertArrayEquals(Arrays.copyOfRange(expect, offset, expect.length), mmu.read("0000000000000000" + read_eip, len - offset).get(0).toCharArray());
    }

    //segment replace test
    @Test
    public void testF() {
        char[] expect1;
        char[] expect2;
        char[] expect3;
        int len;
        int len1;
        int len2;
        int len3;
        int offset1;
        int offset2;
        int offset3;
        String read_eip1;
        String read_eip2;
        String read_eip3;
        String eip = "00000000000000000000000000000000";
        len = 4 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        offset1 = new Random().nextInt(len);
        len1 = new Random().nextInt(len - offset1);
        expect1 = fillData((char) 0b01011001, len1);
        read_eip1 = t.intToBinary(String.valueOf(offset1));
        mmu.write("0000000000000000" + read_eip1, len1, expect1);

        eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        len = 6 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        offset2 = new Random().nextInt(len);
        len2 = new Random().nextInt(len - offset2);
        expect2 = fillData((char) 0b01011010, len2);
        read_eip2 = t.intToBinary(String.valueOf(offset2));
        mmu.write("0000000000001000" + read_eip2, len2, expect2);

        eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        len = 7 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 4 * 1024 * 1024));
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        offset3 = new Random().nextInt(len);
        len3 = new Random().nextInt(len - offset3);
        expect3 = fillData((char) 0b01011100, len3);
        read_eip3 = t.intToBinary(String.valueOf(offset3));
        mmu.write("0000000000010000" + read_eip3, len3, expect3);

        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }

        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }

        if (!Arrays.equals(expect3, mmu.read("0000000000010000" + read_eip3, len3).get(0).toCharArray())) {
            fail();
        }
        assertFalse(Memory.GDT.get(0).isValidBit());
        assertFalse(Memory.GDT.get(1).isValidBit());
        assertTrue(Memory.GDT.get(2).isValidBit());
    }

    @Test
    public void testG() {
        char[] expect1;
        char[] expect2;
        char[] expect3;
        int len;
        int len1;
        int len2;
        int len3;
        int offset1;
        int offset2;
        int offset3;
        String read_eip1;
        String read_eip2;
        String read_eip3;
        String eip = t.intToBinary(String.valueOf(0));
        len = 10 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        offset1 = new Random().nextInt(len);
        len1 = new Random().nextInt(len - offset1);
        expect1 = fillData((char) 0b01111100, len1);
        read_eip1 = t.intToBinary(String.valueOf(offset1));
        mmu.write("0000000000000000" + read_eip1, len1, expect1);

        eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        len = 6 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        offset2 = new Random().nextInt(len);
        len2 = new Random().nextInt(len - offset2);
        expect2 = fillData((char) 0b01011100, len2);
        read_eip2 = t.intToBinary(String.valueOf(offset2));
        mmu.write("0000000000001000" + read_eip2, len2, expect2);

        eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        len = 7 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 4 * 1024 * 1024));
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        offset3 = new Random().nextInt(len);
        len3 = new Random().nextInt(len - offset3);
        expect3 = fillData((char) 0b01011101, len3);
        read_eip3 = t.intToBinary(String.valueOf(offset3));
        mmu.write("0000000000010000" + read_eip3, len3, expect3);

        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }

        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }

        if (!Arrays.equals(expect3, mmu.read("0000000000010000" + read_eip3, len3).get(0).toCharArray())) {
            fail();
        }
        assertFalse(Memory.GDT.get(0).isValidBit());
        assertFalse(Memory.GDT.get(1).isValidBit());
        assertTrue(Memory.GDT.get(2).isValidBit());
    }

    @Test
    public void testH() {
        char[] expect1;
        char[] expect2;
        char[] expect3;
        int len;
        int len1;
        int len2;
        int len3;
        int offset1;
        int offset2;
        int offset3;
        String read_eip1;
        String read_eip2;
        String read_eip3;
        String eip = t.intToBinary(String.valueOf(0));
        len = 10 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        offset1 = new Random().nextInt(len);
        len1 = new Random().nextInt(len - offset1);
        expect1 = fillData((char) 0b01011110, len1);
        read_eip1 = t.intToBinary(String.valueOf(offset1));
        mmu.write("0000000000000000" + read_eip1, len1, expect1);

        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        assertEquals(5, Memory.GDT.get(0).getVisited());
        eip = t.intToBinary(String.valueOf(2 * 1024 * 1024));
        len = 3 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 2 * 1024 * 1024));
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        offset2 = new Random().nextInt(len);
        len2 = new Random().nextInt(len - offset2);
        expect2 = fillData((char) 0b00001100, len2);
        read_eip2 = t.intToBinary(String.valueOf(offset2));
        mmu.write("0000000000001000" + read_eip2, len2, expect2);
        assertFalse(Memory.GDT.get(0).isValidBit());
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        assertEquals(4,Memory.GDT.get(1).getVisited());
        eip = t.intToBinary(String.valueOf(5 * 1024 * 1024));
        len = 7 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 6 * 1024 * 1024));
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        offset3 = new Random().nextInt(len);
        len3 = new Random().nextInt(len - offset3);
        expect3 = fillData((char) 0b01000100, len3);
        read_eip3 = t.intToBinary(String.valueOf(offset3));
        mmu.write("0000000000010000" + read_eip3, len3, expect3);

        if (!Arrays.equals(expect3, mmu.read("0000000000010000" + read_eip3, len3).get(0).toCharArray())) {
            fail();
        }
        assertEquals(2, Memory.GDT.get(2).getVisited());
        assertFalse(Memory.GDT.get(0).isValidBit());
        assertTrue(Memory.GDT.get(1).isValidBit());
        assertTrue(Memory.GDT.get(2).isValidBit());
    }

    @Test
    public void testI() {
        char[] expect1;
        char[] expect2;
        char[] expect3;
        int len;
        int len1;
        int len2;
        int len3;
        int offset1;
        int offset2;
        int offset3;
        String read_eip1;
        String read_eip2;
        String read_eip3;
        String eip = t.intToBinary(String.valueOf(0));
        len = 8 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        offset1 = new Random().nextInt(len);
        len1 = new Random().nextInt(len - offset1);
        expect1 = fillData((char) 0b01011100, len1);
        read_eip1 = t.intToBinary(String.valueOf(offset1));
        //4
        mmu.write("0000000000000000" + read_eip1, len1, expect1);

        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        assertEquals(4, Memory.GDT.get(0).getVisited());

        eip = t.intToBinary(String.valueOf(8 * 1024 * 1024));
        len = 8 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        offset2 = new Random().nextInt(len);
        len2 = new Random().nextInt(len - offset2);
        expect2 = fillData((char) 01011100, len2);
        read_eip2 = t.intToBinary(String.valueOf(offset2));
        mmu.write("0000000000001000" + read_eip2, len2, expect2);
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        assertEquals(2, Memory.GDT.get(1).getVisited());

        eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        len = 2 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 4 * 1024 * 1024));
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        offset3 = new Random().nextInt(len);
        len3 = new Random().nextInt(len - offset3);
        expect3 = fillData((char) 0b01011100, len3);
        read_eip3 = t.intToBinary(String.valueOf(offset3));
        mmu.write("0000000000010000" + read_eip3, len3, expect3);


        if (!Arrays.equals(expect3, mmu.read("0000000000010000" + read_eip3, len3).get(0).toCharArray())) {
            fail();
        }
        assertFalse(Memory.GDT.get(0).isValidBit());
        assertFalse(Memory.GDT.get(1).isValidBit());
        assertTrue(Memory.GDT.get(2).isValidBit());
    }

    @Test
    public void testJ() {
        char[] expect1;
        char[] expect2;
        char[] expect3;
        int len;
        int len1;
        int len2;
        int len3;
        int offset1;
        int offset2;
        int offset3;
        String read_eip1;
        String read_eip2;
        String read_eip3;
        String eip = t.intToBinary(String.valueOf(0));
        len = 8 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        offset1 = new Random().nextInt(len);
        len1 = new Random().nextInt(len - offset1);
        expect1 = fillData((char) 0b01010000, len1);
        read_eip1 = t.intToBinary(String.valueOf(offset1));
        //2
        mmu.write("0000000000000000" + read_eip1, len1, expect1);

        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }


        eip = t.intToBinary(String.valueOf(8 * 1024 * 1024));
        len = 8 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        offset2 = new Random().nextInt(len);
        len2 = new Random().nextInt(len - offset2);
        expect2 = fillData((char) 0b01000001, len2);
        read_eip2 = t.intToBinary(String.valueOf(offset2));
        mmu.write("0000000000001000" + read_eip2, len2, expect2);
        //4
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        len = 2 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 4 * 1024 * 1024));
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        offset3 = new Random().nextInt(len);
        len3 = new Random().nextInt(len - offset3);
        expect3 = fillData((char) 0b00000000, len3);
        read_eip3 = t.intToBinary(String.valueOf(offset3));
        mmu.write("0000000000010000" + read_eip3, len3, expect3);


        if (!Arrays.equals(expect3, mmu.read("0000000000010000" + read_eip3, len3).get(0).toCharArray())) {
            fail();
        }
        assertFalse(Memory.GDT.get(0).isValidBit());
        assertTrue(Memory.GDT.get(1).isValidBit());
        assertTrue(Memory.GDT.get(2).isValidBit());
    }

    @Test
    public void testL() {
        char[] expect1;
        char[] expect2;
        char[] expect3;
        int len;
        int len1;
        int len2;
        int len3;
        int offset1;
        int offset2;
        int offset3;
        String read_eip1;
        String read_eip2;
        String read_eip3;
        String eip = t.intToBinary(String.valueOf(0));
        len = 10 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        offset1 = new Random().nextInt(len);
        len1 = new Random().nextInt(len - offset1);
        expect1 = fillData((char) 0b00001010, len1);
        read_eip1 = t.intToBinary(String.valueOf(offset1));
        mmu.write("0000000000000000" + read_eip1, len1, expect1);

        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }
        assertEquals(5, Memory.GDT.get(0).getVisited());
        eip = t.intToBinary(String.valueOf(2 * 1024 * 1024));
        len = 3 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 2 * 1024 * 1024));
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        offset2 = new Random().nextInt(len);
        len2 = new Random().nextInt(len - offset2);
        expect2 = fillData((char) 0b01111111, len2);
        read_eip2 = t.intToBinary(String.valueOf(offset2));
        mmu.write("0000000000001000" + read_eip2, len2, expect2);
        assertFalse(Memory.GDT.get(0).isValidBit());
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }
        assertEquals(4, Memory.GDT.get(1).getVisited());
        eip = t.intToBinary(String.valueOf(5 * 1024 * 1024));
        len = 7 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 3 * 1024 * 1024));
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        offset3 = new Random().nextInt(len);
        len3 = new Random().nextInt(len - offset3);
        expect3 = fillData((char) 0b01000100, len3);
        read_eip3 = t.intToBinary(String.valueOf(offset3));
        mmu.write("0000000000010000" + read_eip3, len3, expect3);
        assertFalse(Memory.GDT.get(0).isValidBit());
        assertTrue(Memory.GDT.get(1).isValidBit());
        assertFalse(Memory.GDT.get(2).isValidBit());
    }

    @Test
    public void testM() {
        char[] expect1;
        char[] expect2;
        char[] expect3;
        int len;
        int len1;
        int len2;
        int len3;
        int offset1;
        int offset2;
        int offset3;
        String read_eip1;
        String read_eip2;
        String read_eip3;


        String eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        len = 6 * 1024 * 1024;
        String disk_eip = eip;
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        offset1 = new Random().nextInt(len);
        len1 = new Random().nextInt(len - offset1);
        expect1 = fillData((char) 0b00011000, len1);
        read_eip1 = t.intToBinary(String.valueOf(offset1));
        mmu.write("0000000000000000" + read_eip1, len1, expect1);

        eip = t.intToBinary(String.valueOf(0));
        len = 4 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        offset2 = new Random().nextInt(len);
        len2 = new Random().nextInt(len - offset2);
        expect2 = fillData((char) 0b00000000, len2);
        read_eip2 = t.intToBinary(String.valueOf(offset2));
        mmu.write("0000000000001000" + read_eip2, len2, expect2);

        eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        len = 7 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 4 * 1024 * 1024));
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        offset3 = new Random().nextInt(len);
        len3 = new Random().nextInt(len - offset3);
        expect3 = fillData((char) 0b01011100, len3);
        read_eip3 = t.intToBinary(String.valueOf(offset3));
        mmu.write("0000000000010000" + read_eip3, len3, expect3);

        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }

        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }

        if (!Arrays.equals(expect3, mmu.read("0000000000010000" + read_eip3, len3).get(0).toCharArray())) {
            fail();
        }
        assertFalse(Memory.GDT.get(0).isValidBit());
        assertTrue(Memory.GDT.get(1).isValidBit());
        assertTrue(Memory.GDT.get(2).isValidBit());
    }

    @Test
    public void testN() {
        char[] expect1;
        char[] expect2;
        char[] expect3;
        int len;
        int len1;
        int len2;
        int len3;
        int offset1;
        int offset2;
        int offset3;
        String read_eip1;
        String read_eip2;
        String read_eip3;

        String eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        len = 5 * 1024 * 1024;
        String disk_eip = eip;
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        offset1 = new Random().nextInt(len);
        len1 = new Random().nextInt(len - offset1);
        expect1 = fillData((char) 0b01011100, len1);
        read_eip1 = t.intToBinary(String.valueOf(offset1));
        mmu.write("0000000000000000" + read_eip1, len1, expect1);

        eip = t.intToBinary(String.valueOf(0));
        len = 1 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        offset2 = new Random().nextInt(len);
        len2 = new Random().nextInt(len - offset2);
        expect2 = fillData((char) 0b01111101, len2);
        read_eip2 = t.intToBinary(String.valueOf(offset2));
        mmu.write("0000000000001000" + read_eip2, len2, expect2);

        eip = t.intToBinary(String.valueOf(0));
        len = 3 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(32 * 1024 * 1024 + 4 * 1024 * 1024));
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        offset3 = new Random().nextInt(len);
        len3 = new Random().nextInt(len - offset3);
        expect3 = fillData((char) 0b01111110, len3);
        read_eip3 = t.intToBinary(String.valueOf(offset3));
        mmu.write("0000000000010000" + read_eip3, len3, expect3);

        if (!Arrays.equals(expect1, mmu.read("0000000000000000" + read_eip1, len1).get(0).toCharArray())) {
            fail();
        }

        if (!Arrays.equals(expect2, mmu.read("0000000000001000" + read_eip2, len2).get(0).toCharArray())) {
            fail();
        }

        if (!Arrays.equals(expect3, mmu.read("0000000000010000" + read_eip3, len3).get(0).toCharArray())) {
            fail();
        }
        assertFalse(Memory.GDT.get(0).isValidBit());
        assertFalse(Memory.GDT.get(1).isValidBit());
        assertTrue(Memory.GDT.get(2).isValidBit());
        assertEquals(2, Memory.GDT.get(2).getVisited());
    }

    public char[] fillData(char dataUnit, int len) {
        char[] data = new char[len];
        Arrays.fill(data, dataUnit);
        return data;
    }

}
