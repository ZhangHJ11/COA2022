import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import transformer.Transformer;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;

public class CPUTest {


    /**
     * 0 ADD
     * 1 AND
     * 2 OR
     * 3 XOR
     */

    Memory memory = Memory.getMemory();
    Disk disk = Disk.getDisk();
    MMU mmu = MMU.getMMU();
    static Transformer t = new Transformer();
    InputStream in = null;
    PrintStream out = null;

    InputStream inputStream = null;
    OutputStream outputStream = null;

    @Before
    public void setUp() {
        in = System.in;
        out = System.out;
        outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        System.setErr(new PrintStream(outputStream));
    }


    @After
    public void tearDown() {
        System.setIn(in);
        System.setOut(out);
        memory.clear();
    }

    //ADD
    @Test
    public void testA() {
        String cs = "00000000000000000000000000000000";
        int len = 1024;
        char[] operand = new char[] {(char)0b00000000};
        disk.write(cs, 1, operand);
        memory.alloc_seg_force(0, cs, len, false, cs);
        CPU_State.cs.write("0000000000000000");
        String ds = "00000000000000000000100000000000";
        String data = "0000000000000000000000000000000000000000000000000000000000010001";
        disk.write(ds, 8, CPU.ToByteStream(data.toCharArray()));
        memory.alloc_seg_force(1, ds, len, false, ds);
        CPU_State.ds.write("0000000000001000");
        CPU_State.eip.write("00000000000000000000000000000000");
        assertEquals(0, CPU.ICC);
        // get operand
        CPU.exec();
        assertEquals(1, CPU.ICC);
        CPU_State.eip.write("00000000000000000000000000000000");
        // get val
        CPU.exec();
        assertEquals(2, CPU.ICC);
        // exec
        CPU.exec();
        assertEquals(CPU_State.eax.read(), "00000000000000000000000000010001");
        assertEquals(3, CPU.ICC);
        // write
        CPU_State.eip.write("00000000000000000000000000000010");
        CPU.exec();
        assertEquals(0, CPU.ICC);
        char[] expect = CPU.ToByteStream("00000000000000000000000000010001".toCharArray());
        char[] actual = mmu.read(CPU_State.ds.read()+CPU_State.eip.read(), 4).get(0).toCharArray();
        assertArrayEquals(expect, actual);
    }

    //XOR
    @Test
    public void testB() {
        String cs = "00000000000000000000000000000000";
        int len = 1024;
        char[] operand = new char[] {(char)0b00000011};
        disk.write(cs, 1, operand);
        memory.alloc_seg_force(0, cs, len, false, cs);
        CPU_State.cs.write("0000000000000000");
        String ds = "00000000000000000000100000000000";
        String data = "1010101010101010101010101010101010101010101010101010101010101111";
        disk.write(ds, 8, CPU.ToByteStream(data.toCharArray()));
        memory.alloc_seg_force(1, ds, len, false, ds);
        CPU_State.ds.write("0000000000001000");
        CPU_State.eip.write("00000000000000000000000000000000");
        assertEquals(0, CPU.ICC);
        // get operand
        CPU.exec();
        assertEquals(1, CPU.ICC);
        CPU_State.eip.write("00000000000000000000000000000000");
        // get val
        CPU.exec();
        assertEquals(2, CPU.ICC);
        // exec
        CPU.exec();
        assertEquals("00000000000000000000000000000101", CPU_State.eax.read());
        assertEquals(3, CPU.ICC);
        // write
        CPU_State.eip.write("00000000000000000000000000000010");
        CPU.exec();
        assertEquals(0, CPU.ICC);
        char[] expect = CPU.ToByteStream("00000000000000000000000000000101".toCharArray());
        char[] actual = mmu.read(CPU_State.ds.read()+CPU_State.eip.read(), 4).get(0).toCharArray();
        assertArrayEquals(expect, actual);
    }

    //OR
    @Test
    public void testC() {
        String cs = "00000000000000000000000000000000";
        int len = 1024;
        char[] operand = new char[] {(char)0b00000010};
        disk.write(cs, 1, operand);
        memory.alloc_seg_force(0, cs, len, false, cs);
        CPU_State.cs.write("0000000000000000");
        String ds = "00000000000000000000100000000000";
        String data = "11010101011010100010101010101111" +
                      "10101010101010101010101010101010";
        disk.write(ds, 8, CPU.ToByteStream(data.toCharArray()));
        memory.alloc_seg_force(1, ds, len, false, ds);
        CPU_State.ds.write("0000000000001000");
        CPU_State.eip.write("00000000000000000000000000000000");
        assertEquals(0, CPU.ICC);
        // get operand
        CPU.exec();
        assertEquals(1, CPU.ICC);
        CPU_State.eip.write("00000000000000000000000000000000");
        // get val
        CPU.exec();
        assertEquals(2, CPU.ICC);
        // exec
        CPU.exec();
        assertEquals("11111111111010101010101010101111", CPU_State.eax.read());
        assertEquals(3, CPU.ICC);
        // write
        CPU_State.eip.write("00000000000000000000000000000010");
        CPU.exec();
        assertEquals(0, CPU.ICC);
        char[] expect = CPU.ToByteStream("11111111111010101010101010101111".toCharArray());
        char[] actual = mmu.read(CPU_State.ds.read()+CPU_State.eip.read(), 4).get(0).toCharArray();
        assertArrayEquals(expect, actual);
    }

    //AND
    @Test
    public void testD() {
        String cs = "00000000000000000000000000000000";
        int len = 1024;
        char[] operand = new char[] {(char)0b00000001};
        disk.write(cs, 1, operand);
        memory.alloc_seg_force(0, cs, len, false, cs);
        CPU_State.cs.write("0000000000000000");
        String ds = "00000000000000000000100000000000";
        String data = "11010101011010100010101010101111" +
                      "10101010101010101010101010101010";
        disk.write(ds, 8, CPU.ToByteStream(data.toCharArray()));
        memory.alloc_seg_force(1, ds, len, false, ds);
        CPU_State.ds.write("0000000000001000");
        CPU_State.eip.write("00000000000000000000000000000000");
        assertEquals(0, CPU.ICC);
        // get operand
        CPU.exec();
        assertEquals(1, CPU.ICC);
        CPU_State.eip.write("00000000000000000000000000000000");
        // get val
        CPU.exec();
        assertEquals(2, CPU.ICC);
        // exec
        CPU.exec();
        assertEquals("10000000001010100010101010101010", CPU_State.eax.read());
        assertEquals(3, CPU.ICC);
        // write
        CPU_State.eip.write("00000000000000000000000000000010");
        CPU.exec();
        assertEquals(0, CPU.ICC);
        char[] expect = CPU.ToByteStream("10000000001010100010101010101010".toCharArray());
        char[] actual = mmu.read(CPU_State.ds.read()+CPU_State.eip.read(), 4).get(0).toCharArray();
        assertArrayEquals(expect, actual);
    }

    //斐波那契
    @Test
    public void testE() {
        String cs = "00000000000000000000000000000000";
        int len = 1024;
        char[] operand = new char[] {(char)0b00000000};
        disk.write(cs, 1, operand);
        memory.alloc_seg_force(0, cs, len, false, cs);
        CPU_State.cs.write("0000000000000000");
        String ds = "00000000000000000000100000000000";
        String data = "00000000000000000000000000000001" +
                      "00000000000000000000000000000001";
        disk.write(ds, 8, CPU.ToByteStream(data.toCharArray()));
        memory.alloc_seg_force(1, ds, len, false, ds);
        CPU_State.ds.write("0000000000001000");
        String cseip = "00000000000000000000000000000000";
        String dseip = "00000000000000000000000000000000";
        String[] s = {
                "00000000000000000000000000000010",
                "00000000000000000000000000000011",
                "00000000000000000000000000000101",
                "00000000000000000000000000001000",
                "00000000000000000000000000001101",
                "00000000000000000000000000010101",
                "00000000000000000000000000100010",
                "00000000000000000000000000110111",
                "00000000000000000000000001011001",
                "00000000000000000000000010010000",
                "00000000000000000000000011101001",
                "00000000000000000000000101111001",
                "00000000000000000000001001100010",
                "00000000000000000000001111011011",
                "00000000000000000000011000111101",
                "00000000000000000000101000011000",
                "00000000000000000001000001010101",
                "00000000000000000001101001101101",
                "00000000000000000010101011000010",
                "00000000000000000100010100101111",
                "00000000000000000110111111110001",
                "00000000000000001011010100100000",
                "00000000000000010010010100010001",
                "00000000000000011101101000110001",
                "00000000000000101111111101000010",
                "00000000000001001101100101110011",
                "00000000000001111101100010110101",
                "00000000000011001011001000101000",
                "00000000000101001000101011011101",
                "00000000001000010011110100000101",
                "00000000001101011100011111100010",
                "00000000010101110000010011100111",
                "00000000100011001100110011001001",
                "00000000111000111101000110110000",
                "00000001011100001001111001111001",
                "00000010010101000111000000101001",
                "00000011110001010000111010100010",
                "00000110000110010111111011001011",
                "00001001110111101000110101101101",
                "00001111111110000000110000111000",
        };
        for(int i = 0;i<40;i++){
            CPU_State.eip.write(cseip);
            CPU.exec();
            CPU_State.eip.write(dseip);
            CPU.exec();
            CPU.exec();
            assertEquals(s[i], CPU_State.eax.read());
            CPU_State.eip.write(Helper.add(dseip, t.intToBinary("8")).get(0));
            CPU.exec();
            dseip = Helper.add(dseip, t.intToBinary("4")).get(0);
            assertArrayEquals(CPU.ToByteStream(s[i].toCharArray()) , mmu.read(CPU_State.ds.read()+Helper.add(dseip, t.intToBinary("4")).get(0), 4).get(0).toCharArray());
        }
        char[] expect = CPU.ToByteStream("00001001110111101000110101101101".toCharArray());
        char[] actual = mmu.read(CPU_State.ds.read()+dseip, 4).get(0).toCharArray();
        assertArrayEquals(expect, actual);
    }

    //取反加一
    @Test
    public void testF(){
        String cs = "00000000000000000000000000000000";
        int len = 1024;
        char[] operand = new char[] {(char)0b00000011, (char)0b00000000};
        disk.write(cs, 1, operand);
        memory.alloc_seg_force(0, cs, len, false, cs);
        CPU_State.cs.write("0000000000000000");
        String ds = "00000000000000000000100000000000";
        String data = "00000000000000000000000000000111" +
                      "11111111111111111111111111111111" +
                      "00000000000000000000000000000001";
        disk.write(ds, 12, CPU.ToByteStream(data.toCharArray()));
        memory.alloc_seg_force(1, ds, len, false, ds);
        CPU_State.ds.write("0000000000001000");
        //XOR
        CPU_State.eip.write("00000000000000000000000000000000");
        CPU.exec();
        CPU_State.eip.write("00000000000000000000000000000000");
        CPU.exec();
        CPU.exec();
        assertEquals("11111111111111111111111111111000", CPU_State.eax.read());
        CPU_State.eip.write("00000000000000000000000000000100");
        CPU.exec();
        //ADD
        CPU_State.eip.write("00000000000000000000000000000001");
        CPU.exec();
        CPU_State.eip.write("00000000000000000000000000000100");
        CPU.exec();
        CPU.exec();
        assertEquals("11111111111111111111111111111001", CPU_State.eax.read());
        CPU_State.eip.write("00000000000000000000000000000100");
        CPU.exec();
        char[] expect = CPU.ToByteStream("11111111111111111111111111111001".toCharArray());
        char[] actual = mmu.read(CPU_State.ds.read()+CPU_State.eip.read(), 4).get(0).toCharArray();
        assertArrayEquals(expect, actual);
    }
}
