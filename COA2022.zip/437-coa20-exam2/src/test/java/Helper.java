import java.util.ArrayList;


public class Helper {
    //add two integer
    public static ArrayList<String> add(String src, String dest) {
        // add two integer in 2's complement code
        ArrayList<String> res = new ArrayList<>();
        StringBuilder stringBuilder = new StringBuilder();
        String result = adder(src, dest, '0', 32, stringBuilder);  //注意有进位不等于溢出，溢出要另外判断。已经被封装在上一步
        res.add(result);
        res.add(stringBuilder.reverse().toString());
        return res;
    }

    private static String adder(String operand1, String operand2, char c, int length, StringBuilder cs) {
        operand1 = impleDigits(operand1, length);
        operand2 = impleDigits(operand2, length);
        String res = carry_adder(operand1, operand2, c, length, cs);
        return res;  //注意有进位不等于溢出，溢出要另外判断
    }

    /**
     * test if add given two nums overflow
     *
     * @param operand1 first
     * @param operand2 second
     * @param result   result after the adding
     * @return 1 means overflow, 0 means not
     */
    private String addOverFlow(String operand1, String operand2, String result) {
        int X = operand1.charAt(0) - '0';
        int Y = operand2.charAt(0) - '0';
        int S = result.charAt(0) - '0';
        return "" + ((~X & ~Y & S) | (X & Y & ~S));  //两个操作数符号相同，和结果符号不同，则溢出
    }

    /**
     * add two nums with the length of given length
     * @param operand1 first
     * @param operand2 second
     * @param c        original carray
     * @param length   given length
     * @return result
     */
    private static String carry_adder(String operand1, String operand2, char c, int length, StringBuilder cs) {
        operand1 = impleDigits(operand1, length);
        operand2 = impleDigits(operand2, length);
        String res = "";
        char carry = c;
        for (int i = length - 1; i >= 0; i--) {  //这里length不一定是4的倍数，采用更加通用的加法算法
            cs.append(carry);
            String temp = fullAdder(operand1.charAt(i), operand2.charAt(i), carry);
            carry = temp.charAt(0);
            res = temp.charAt(1) + res;
        }
        cs.append(carry);
        return res;  //注意这个方法里面溢出即有进位
    }

    /**
     * given a length, make operand to that digits considering the sign
     *
     * @param operand given num
     * @param length  make complete
     * @return completed string
     */
    private static String impleDigits(String operand, int length) {
        int len = length - operand.length();
        char imple = operand.charAt(0);
        StringBuffer res = new StringBuffer(new StringBuffer(operand).reverse());
        for (int i = 0; i < len; i++) {
            res = res.append(imple);
        }
        return res.reverse().toString();
    }

    private static String fullAdder(char x, char y, char c) {
        int bit = (x - '0') ^ (y - '0') ^ (c - '0');  //三位异或
        int carry = ((x - '0') & (y - '0')) | ((y - '0') & (c - '0')) | ((x - '0') & (c - '0'));  //有两位为1则产生进位
        return "" + carry + bit;  //第一个空串让后面的加法都变为字符串加法
    }
}
