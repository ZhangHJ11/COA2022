import org.junit.*;
import org.junit.runners.MethodSorters;
import transformer.Transformer;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class MemoryTest {

    static Memory memory = Memory.getMemory();
    static Transformer t = new Transformer();
    private static HashMap<String, ArrayList<String>> seg_load_case = new HashMap<>();

    InputStream in = null;
    PrintStream out = null;
    PrintStream err = null;
    InputStream inputStream = null;
    OutputStream outputStream = null;

    @Before
    public void setUp() {
        in = System.in;
        out = System.out;
        err = System.err;
        Memory.SEGMENT_REPLACE = false;
        outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        System.setErr(new PrintStream(outputStream));
    }


    @After
    public void tearDown() {
        System.setIn(in);
        System.setOut(out);
        System.setErr(err);
        memory.clear();
    }

    @BeforeClass
    public static void init() {
        String[] case1 = {
                "00000000000000000000000000000000",
                "0000000000100000000000000000000",
                "00000000000000000000000000000000"
        };
        seg_load_case.put("case1", buildTruth(case1));
        String[] case2 = {
                "00000000110001010010100011010001",
                "0000000001110001100101010000110",
                "00000001110110001011100101101100",
        };
        seg_load_case.put("case2", buildTruth(case2));
        String[] case3 = {
                "00000000010001110110110001111101",
                "0000000010001011111010001101010",
                "00000010100011101001101010111010",
        };
        seg_load_case.put("case3", buildTruth(case3));

        String[] case4 = {
                "00000000010101100110000101011010",
                "0000000010001011001000010111101",
                "00000000111110010011010011111111",
        };
        seg_load_case.put("case4", buildTruth(case4));
        String[] case5 = {
                "00000000011000010111101001100011",
                "0000000001101101000100110100101",
                "00000001110111111011000100010010",
        };
        seg_load_case.put("case5", buildTruth(case5));
        String[] case6 = {
                "00000000100010001000100101000110",
                "0000000011010111111100101000010",
                "00000000100010111101100001100001",
        };
        seg_load_case.put("case6", buildTruth(case6));
        String[] case7 = {
                "00000000011100110110000100101101",
                "0000000010011001110100100111101",
                "00000000000100000111111101001001",
        };
        seg_load_case.put("case7", buildTruth(case7));
        String[] case8 = {
                "00000000000101111001110101111100",
                "0000000011110001011000110111010",
                "00000000101110111010001010111111",
        };
        seg_load_case.put("case8", buildTruth(case8));
        String[] case9 = {
                "00000000011000001000100101110010",
                "0000000100001101110010011101101",
                "00000001010000000010110101101111",
        };
        seg_load_case.put("case9", buildTruth(case9));
        String[] case10 = {
                "00000000101111000010011001000111",
                "0000000000111000101100111110111",
                "00000010101010011000010100010100",
        };
        seg_load_case.put("case10", buildTruth(case10));
        String[] case11 = {
                "-1"
        };
        String[] caseO = {
                "00000000000000000000000000000000", "0000000010000000000000000000000", "00000000000000000000000000000000"
        };
        seg_load_case.put("case11", buildTruth(case11));
        seg_load_case.put("caseO", buildTruth(caseO));
        String[] caseP = {
                "00000000101000000000000000000000", "0000000011000000000000000000000", "00000000101000000000000000000000"
        };
        seg_load_case.put("caseP", buildTruth(caseP));
        String[] caseQ = {
                "00000000010000000000000000000000", "0000000011000000000000000000000", "00000000010000000000000000000000"
        };
        seg_load_case.put("caseQ", buildTruth(caseQ));
        String[] caseV = {
                "00000000001110100010110101000011",
                "0000000000000000110100101010000",
                "00000010001100011011000000000101",
        };

    }

    @Test
    public void testB() {
        String memory_eip = "00000000110001010010100011010001";
        String disk_eip = "00000001110110001011100101101100";
        int len = 3721862;
        memory.alloc_seg_force(0, memory_eip, len, false, disk_eip);
        ArrayList<String> actual = memory.seg_load(0);
        assertEquals(seg_load_case.get("case2"), actual);
    }

    @Test
    public void testD() {
        String memory_eip = "00000000010101100110000101011010";
        String disk_eip = "00000000111110010011010011111111";
        int len = 4559037;
        memory.alloc_seg_force(0, memory_eip, len, false, disk_eip);
        ArrayList<String> actual = memory.seg_load(0);
        assertEquals(seg_load_case.get("case4"), actual);
    }


    @Test
    public void testK() {
        String memory_eip = "00000000000000000000000000000000";
        int len = 20 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, memory_eip, len, false, disk_eip);
        ArrayList<String> actual = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("case11"), actual));
    }

    @Test
    public void testL() {

        String memory_eip = "00000000010000000000000000000000";
        int len = 14 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, memory_eip, len, false, disk_eip);
        ArrayList<String> actual = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("case11"), actual));

    }

    @Test
    public void testM() {
        String eip = "00000000000000000000000000000000";
        int len = 1024 * 1024;
        memory.alloc_seg_force(0, eip, len, false, eip);
        ArrayList<String> actual = memory.seg_load(3);
        assertTrue(isSame(seg_load_case.get("case11"), actual));
    }

    @Test
    public void testN() {
        String eip = "00000000000000000000000000000000";
        int len = 4 * 1024 * 1024;
        String disk_eip = t.intToBinary(String.valueOf(61 * 1024 * 1024));
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        ArrayList<String> actual = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("case11"), actual));
    }

    // cant load two seg
    @Test
    public void testO() {
        String eip = "00000000000000000000000000000000";
        int len = 4 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        ArrayList<String> actual1 = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("caseO"), actual1));

        len = 7 * 1024 * 1024;
        eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        ArrayList<String> actual2 = memory.seg_load(1);
        assertTrue(isSame(seg_load_case.get("case11"), actual2));
    }

    // load two seg
    @Test
    public void testP() {
        String eip = "00000000000000000000000000000000";
        int len = 4 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        ArrayList<String> actual1 = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("caseO"), actual1));


        len = 6 * 1024 * 1024;
        eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        ArrayList<String> actual2 = memory.seg_load(1);
        assertTrue(isSame(seg_load_case.get("caseP"), actual2));
    }

    // all in memory
    @Test
    public void testQ() {
        String eip = "00000000000000000000000000000000";
        int len = 4 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        ArrayList<String> actual1 = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("caseO"), actual1));


        len = 6 * 1024 * 1024;
        eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        ArrayList<String> actual2 = memory.seg_load(1);
        assertTrue(isSame(seg_load_case.get("caseP"), actual2));


        len = 6 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        ArrayList<String> actual3 = memory.seg_load(2);
        assertTrue(isSame(seg_load_case.get("caseQ"), actual3));
    }

    // out of memory
    @Test
    public void testR() {
        String eip = "00000000000000000000000000000000";
        int len = 4 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        ArrayList<String> actual1 = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("caseO"), actual1));

        len = 6 * 1024 * 1024;
        eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        ArrayList<String> actual2 = memory.seg_load(1);
        assertTrue(isSame(seg_load_case.get("caseP"), actual2));

        eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        len = 7 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        ArrayList<String> actual3 = memory.seg_load(2);
        assertTrue(isSame(seg_load_case.get("case11"), actual3));
    }

    @Test
    public void testS() {
        String eip = "00000000000000000000000000000000";
        int len = 4 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        ArrayList<String> actual1 = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("caseO"), actual1));

        len = 6 * 1024 * 1024;
        eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        ArrayList<String> actual2 = memory.seg_load(1);
        assertTrue(isSame(seg_load_case.get("caseP"), actual2));

        eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        len = 7 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        ArrayList<String> actual3 = memory.seg_load(2);
        assertTrue(isSame(seg_load_case.get("case11"), actual3));

        eip = t.intToBinary(String.valueOf(-4 * 1024 * 1024));
        len = 5 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        memory.alloc_seg_force(3, eip, len, false, disk_eip);
        ArrayList<String> actual4 = memory.seg_load(3);
        assertTrue(isSame(seg_load_case.get("case11"), actual4));
    }

    @Test
    public void testT() {
        String eip = "00000000000000000000000000000000";
        int len = 4 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        ArrayList<String> actual1 = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("caseO"), actual1));

        len = 6 * 1024 * 1024;
        eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        ArrayList<String> actual2 = memory.seg_load(1);
        assertTrue(isSame(seg_load_case.get("caseP"), actual2));

        eip = t.intToBinary(String.valueOf(4 * 1024 * 1024));
        len = 7 * 1024 * 1024;
        disk_eip = eip;
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        ArrayList<String> actual3 = memory.seg_load(2);
        assertTrue(isSame(seg_load_case.get("case11"), actual3));

        eip = t.intToBinary(String.valueOf(-4 * 1024 * 1024));
        len = 5 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(-4 * 1024 * 1024));
        memory.alloc_seg_force(3, eip, len, false, disk_eip);
        ArrayList<String> actual4 = memory.seg_load(3);
        assertTrue(isSame(seg_load_case.get("case11"), actual4));
    }

    @Test
    public void testU() {
        String eip = "00000000000000000000000000000000";
        int len = 4 * 1024 * 1024;
        String disk_eip = "00000000000000000000000000000000";
        memory.alloc_seg_force(0, eip, len, false, disk_eip);
        ArrayList<String> actual1 = memory.seg_load(0);
        assertTrue(isSame(seg_load_case.get("caseO"), actual1));

        len = 6 * 1024 * 1024;
        eip = t.intToBinary(String.valueOf(10 * 1024 * 1024));
        disk_eip = eip;
        memory.alloc_seg_force(1, eip, len, false, disk_eip);
        ArrayList<String> actual2 = memory.seg_load(1);
        assertTrue(isSame(seg_load_case.get("caseP"), actual2));

        eip = t.intToBinary(String.valueOf(12 * 1024 * 1024));
        len = -5 * 1024 * 1024;
        disk_eip = t.intToBinary(String.valueOf(12 * 1024 * 1024));
        memory.alloc_seg_force(2, eip, len, false, disk_eip);
        ArrayList<String> actual3 = memory.seg_load(2);
        assertTrue(isSame(seg_load_case.get("case11"), actual3));
    }


    private static ArrayList<String> buildTruth(String[] input) {
        return new ArrayList<>(Arrays.asList(input));
    }

    private boolean isSame(ArrayList<String> expected, ArrayList<String> log) {
        if (expected == null || log == null) {
            return false;
        }
        if (expected.size() != log.size()) {
            return false;
        }
        for (int i = 0; i < log.size(); i++) {
            if (!log.get(i).equals(expected.get(i))) {
                return false;
            }
        }
        return true;
    }

}
