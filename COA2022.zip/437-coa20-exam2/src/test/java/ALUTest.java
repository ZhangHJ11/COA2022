import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import registers.EFlag;
import transformer.Transformer;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.PrintStream;
import java.util.ArrayList;

import static org.junit.Assert.assertEquals;


public class ALUTest {

    Transformer t = new Transformer();
    ALU alu = new ALU();

    InputStream in = null;
    PrintStream out = null;
    PrintStream err = null;
    InputStream inputStream = null;
    OutputStream outputStream = null;

    @Before
    public void setUp() {
        in = System.in;
        out = System.out;
        err = System.err;
        outputStream = new ByteArrayOutputStream();
        System.setOut(new PrintStream(outputStream));
        System.setErr(new PrintStream(outputStream));
    }


    @After
    public void tearDown() {
        System.setIn(in);
        System.setOut(out);
        System.setErr(err);
    }


    // basic test
    @Test
    public void ADDTest1() {
        ArrayList<ArrayList<String>> expect = new ArrayList<>();
        ArrayList<ArrayList<String>> actual = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < 100; j++) {
                expect.add(Helper.add(t.intToBinary(String.valueOf(i)), t.intToBinary(String.valueOf(j))));
                actual.add(alu.add(t.intToBinary(String.valueOf(i)), t.intToBinary(String.valueOf(j))));
            }
        }
        assertEquals(expect, actual);
    }

    @Test
    public void ADDTest9() {
        ArrayList<ArrayList<String>> expect = new ArrayList<>();
        ArrayList<ArrayList<String>> actual = new ArrayList<>();
        for (int i = -100; i <= 0; i++) {
            for (int j = -100; j <= 0; j++) {
                expect.add(Helper.add(t.intToBinary(String.valueOf(i)), t.intToBinary(String.valueOf(j))));
                actual.add(alu.add(t.intToBinary(String.valueOf(i)), t.intToBinary(String.valueOf(j))));
            }
        }
        assertEquals(expect, actual);
    }

    // min + max test
    @Test
    public void ADDTest2() {
        String a = "10000000000000000000000000000000";
        String b = "01111111111111111111111111111111";
        ArrayList<String> res = alu.add(a, b);
        if (!res.get(0).equals("11111111111111111111111111111111")) {
            Assert.fail();
        }
        if (!res.get(1).equals("000000000000000000000000000000000")) {
            Assert.fail();
        }
    }

    // overflow test
    @Test
    public void ADDTest3() {
        String a = "01111111111111111111111111111111";
        String b = "00000001111111111111111111111111";
        ArrayList<String> res = alu.add(a, b);
        EFlag r = (EFlag) CPU_State.eflag;
        if (!r.getOF()) {
            Assert.fail();
        }
        if (!res.get(1).equals("011111111111111111111111111111110")) {
            Assert.fail();
        }
    }

    // overflow test
    @Test
    public void ADDTest4() {
        String a = "11111111111111111111111111111100";
        String b = "10000000000000000000000000000000";
        alu.add(a, b);
        EFlag r = (EFlag) CPU_State.eflag;
        if (!r.getOF()) {
            Assert.fail();
        }
        if (!r.getCF()) {
            Assert.fail();
        }
    }


    @Test
    public void testAnd1() {
        if (!"00000000000000000000000000000001".equals(alu.and("00000000000000000000000000000101", "10010010101001000001101110101001"))) {
            Assert.fail();
        }
    }

    @Test
    public void testOr1() {
        if (!"10010010101001000001101110101101".equals(alu.or("00000000000000000000000000000101", "10010010101001000001101110101001"))) {
            Assert.fail();
        }
    }

    @Test
    public void testXor1() {
        if (!"10010010101001000001101110101100".equals(alu.xor("00000000000000000000000000000101", "10010010101001000001101110101001"))) {
            Assert.fail();
        }
    }
}
