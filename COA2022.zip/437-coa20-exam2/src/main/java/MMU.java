import java.util.ArrayList;
import java.util.Arrays;

public class MMU {


    private static MMU mmuInstance = new MMU();

    private MMU() {
    }

    public static MMU getMMU() {
        return mmuInstance;
    }


    Memory memory = Memory.getMemory();

    /**
     * 从内存中读出数据
     *
     * @param logicAddr 逻辑地址
     * @param len       数据长度
     * @return
     */
    public ArrayList<String> read(String logicAddr, int len) {
        //TODO
        return new ArrayList<>(Arrays.asList("0"));
    }

    /**
     * 将数据写入内存之中
     *
     * @param logicAddr 逻辑地址
     * @param len       数据长度
     * @param data      数据
     */
    public void write(String logicAddr, int len, char[] data) {
        //TODO
    }
}
