import transformer.Transformer;

import java.util.ArrayList;
import java.util.Arrays;


public class Memory {

    public static ArrayList<SegDescriptor> GDT = new ArrayList<>();

    private Memory() {

    }

    Disk disk = Disk.getDisk();

    public static boolean SEGMENT_REPLACE = false;

    public static int MEM_SIZE_B = 16 * 1024 * 1024; // 16MB

    public static char[] memory = new char[MEM_SIZE_B];

    public static Memory memoryInstance = new Memory();

    public static Memory getMemory() {
        return memoryInstance;
    }

    public char[] read(int index, int len) {
        return Arrays.copyOfRange(memory, index, index + len);
    }

    public void write(int index, int len, char[] data) {
        for (int i = 0; i < len; i++) {
            memory[i + index] = data[i];
        }
    }

    /**
     * @param segIndex 段选择子的下标
     * @return ArrayList<String>，其中元素依次是段选择子的基址、限长和硬盘起始地址；若该段选择子不存在或者段无法被加载到内存中，则ArrayList中仅需包含字符串“-1”
     */
    public ArrayList<String> seg_load(int segIndex) {
        //TODO
        return null;
    }

    /**
     * 此方法仅被测试用例使用，请勿修改
     */
    public void alloc_seg_force(int segSelector, String eip, int len, boolean isValid, String disk_base) {
        SegDescriptor sd = new SegDescriptor();
        Transformer t = new Transformer();
        sd.setDisk_base(disk_base.toCharArray());
        sd.setBase(eip.toCharArray());
        sd.setLimit(t.intToBinary(String.valueOf(len)).substring(1, 32).toCharArray());
        sd.setValidBit(isValid);
        Memory.GDT.add(segSelector, sd);
    }


    public void clear() {
        GDT = new ArrayList<>();
        Arrays.fill(memory, (char) 0b00000000);
    }
}
