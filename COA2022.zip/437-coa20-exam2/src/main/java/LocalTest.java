import java.util.ArrayList;
import java.util.Arrays;

public class LocalTest {
    public static void main(String[] args) {
        LocalTest localTest = new LocalTest();
        localTest.ADDTest();
        localTest.ORTest();
        localTest.ANDTest();
        localTest.XORTest();
        localTest.MemoryTest();
        localTest.MMUReadTest();
        localTest.MMUWriteTest();
        localTest.CPUTest();
    }

    public void ADDTest() {
        String a = "00000000000000111110000000000000";
        String b = "00000000000000111110000000000000";
        ALU alu = new ALU();
        ArrayList<String> res = new ArrayList<>();
        res.add("00000000000001111100000000000000");
        res.add("000000000000001111100000000000000");
        System.out.print("ADD Test: ");
        System.out.println(isSame(res, alu.add(a, b)));
    }

    public void ORTest() {
        String a = "00000000000000111110000000000000";
        String b = "00000000000000111110000000000000";
        ALU alu = new ALU();
        System.out.print("OR Test: ");
        System.out.println("00000000000000111110000000000000".equals(alu.or(a, b)));
    }

    public void ANDTest() {
        String a = "00000000000000110110000000000000";
        String b = "00000000000000111110000000000000";
        ALU alu = new ALU();
        System.out.print("AND Test: ");
        System.out.println("00000000000000110110000000000000".equals(alu.and(a, b)));
    }

    public void XORTest() {
        String a = "00000000000000110110000000000000";
        String b = "00000000000000111110000000000000";
        ALU alu = new ALU();
        System.out.print("XOR Test: ");
        System.out.println("00000000000000001000000000000000".equals(alu.xor(a, b)));
    }

    public void MemoryTest() {
        String eip = "00000000000000000000000000000000";
        int len = 1024 * 1024;
        Memory.getMemory().clear();
        Memory.getMemory().alloc_seg_force(0, eip, len, false, eip);
        ArrayList<String> expect = new ArrayList<>();
        expect.add("00000000000000000000000000000000");
        expect.add("0000000000100000000000000000000");
        expect.add("00000000000000000000000000000000");
        ArrayList<String> actual = Memory.getMemory().seg_load(0);
        System.out.print("Memory Test: ");
        System.out.println(isSame(expect, actual));
    }

    public void MMUReadTest() {
        String eip = "00000000000000000000000000000000";
        int len = 1024 * 1024;
        Memory.getMemory().clear();
        char[] expect = fillData((char) 0b00001111, len);
        Disk.getDisk().write(eip, len, expect);
        Memory.getMemory().alloc_seg_force(0, eip, len, false, eip);
        Memory.getMemory().seg_load(0);
        System.out.print("MMURead Test: ");
        System.out.println(Arrays.equals(expect, MMU.getMMU().read("000000000000000000000000000000000000000000000000", len).get(0).toCharArray()));
    }
    public void MMUWriteTest() {
        String eip = "00000000000000000000000000000000";
        int len = 1024 * 1024;
        Memory.getMemory().clear();
        char[] expect = fillData((char) 0b00001111, len);
        Memory.getMemory().alloc_seg_force(0, eip, len, false, eip);
        Memory.getMemory().seg_load(0);
        MMU.getMMU().write("000000000000000000000000000000000000000000000000", len, expect);
        System.out.print("MMUWrite Test: ");
        System.out.println(Arrays.equals(expect, MMU.getMMU().read("000000000000000000000000000000000000000000000000", len).get(0).toCharArray()));
    }
    public void CPUTest() {
        String cs = "00000000000000000000000000000000";
        int len = 1024;
        char[] operand = new char[] {(char)0b00000011};
        Disk.getDisk().write(cs, 1, operand);
        Memory.getMemory().clear();
        Memory.getMemory().alloc_seg_force(0, cs, len, false, cs);
        CPU_State.cs.write("0000000000000000");
        String ds = "00000000000000000000100000000000";
        String data = "1010101010101010101010101010101010101010101010101010101010101010";
        Disk.getDisk().write(ds, 8, CPU.ToByteStream(data.toCharArray()));
        Memory.getMemory().alloc_seg_force(1, ds, len, false, ds);
        CPU_State.ds.write("0000000000001000");
        CPU_State.eip.write("00000000000000000000000000000000");
        // get operand
        CPU.exec();
        CPU_State.eip.write("00000000000000000000000000000000");
        // get val
        CPU.exec();
        // exec
        CPU.exec();
        System.out.print("CPU Test1: ");
        System.out.println("00000000000000000000000000000000".equals(CPU_State.eax.read()));
        // write
        CPU_State.eip.write("00000000000000000000000000000010");
        CPU.exec();
        char[] expect = CPU.ToByteStream("00000000000000000000000000000000".toCharArray());
        char[] actual = MMU.getMMU().read(CPU_State.ds.read()+CPU_State.eip.read(), 4).get(0).toCharArray();
        System.out.print("CPU Test2: ");
        System.out.println(Arrays.equals(expect, actual));
    }

    private boolean isSame(ArrayList<String> expected, ArrayList<String> log) {
        if (expected == null || log == null) {
            return false;
        }
        if (expected.size() != log.size()) {
            return false;
        }
        for (int i = 0; i < log.size(); i++) {
            if (!log.get(i).equals(expected.get(i))) {
                return false;
            }
        }
        return true;
    }

    public char[] fillData(char dataUnit, int len) {
        char[] data = new char[len];
        Arrays.fill(data, dataUnit);
        return data;
    }

}
