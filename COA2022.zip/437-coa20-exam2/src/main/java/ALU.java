import registers.EFlag;

import java.util.ArrayList;


public class ALU {

    private EFlag eflag = (EFlag) CPU_State.eflag;


    /**
     * @param src  32位操作数1
     * @param dest 32位操作数2
     * @return ArrayList，其中第一个元素是长度为32的字符串，表示和，第二个元素是长度为33的字符串（CnCn-1…C1C0）
     */
    public ArrayList<String> add(String src, String dest) {
        //TODO
        return null;
    }




    /**
     * @param src  32位操作数1
     * @param dest 32位操作数2
     * @return 结果
     */
    public String and(String src, String dest) {
        //TODO
        return null;
    }

    /**
     * @param src  32位操作数1
     * @param dest 32位操作数2
     * @return 结果
     */
    public String or(String src, String dest) {
        //TODO
        return null;
    }

    /**
     * @param src  32位操作数1
     * @param dest 32位操作数2
     * @return 结果
     */
    public String xor(String src, String dest) {
        //TODO
        return null;
    }

}
