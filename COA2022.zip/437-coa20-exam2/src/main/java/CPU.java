public class CPU {
    static int ICC = 0;  //control unit

    public static void exec() {
        switch (ICC) {
            // TODO
            default: {
                ICC = -1;
            }
        }
    }

    /**
     * 将Byte流转换成Bit流
     *
     * @param data
     * @return
     */
    public static char[] ToBitStream(char[] data) {
        char[] t = new char[data.length * 8];
        int index = 0;
        for (char datum : data) {
            for (int j = 0; j < 8; j++) {
                t[index++] = (char) (((datum >> (7 - j)) & (0b00000001)) + '0');
            }
        }
        return t;
    }

    /**
     * 将Bit流转换为Byte流
     *
     * @param data
     * @return
     */
    public static char[] ToByteStream(char[] data) {
        char[] t = new char[data.length / 8];
        int j = 0;
        int index = 0;
        for (char datum : data) {
            t[index] = (char) ((datum - '0' << (7 - j)) | t[index]);
            j++;
            if (j % 8 == 0) {
                index++;
                j = 0;
            }
        }
        return t;
    }

}
