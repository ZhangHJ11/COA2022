public class SegDescriptor {

    // 段基址在缺段中断发生时可能会产生变化，内存重新为段分配内存基址
    private char[] base = new char[32];  // 32位基地址

    private char[] limit = new char[31]; // 31位限长，表示段在内存中的长度

    private boolean validBit = false;    // 有效位,为true表示被占用（段已在内存中），为false表示空闲（不在内存中）

    private char[] disk_base = new char[32];

    private long visited = 0l;

    private boolean dirty = false;

    public char[] getBase() {
        return base;
    }

    public void setBase(char[] base) {
        this.base = base;
    }

    public char[] getLimit() {
        return limit;
    }

    public void setLimit(char[] limit) {
        this.limit = limit;
    }

    public boolean isValidBit() {
        return validBit;
    }

    public void setValidBit(boolean validBit) {
        this.validBit = validBit;
    }

    public char[] getDisk_base() {
        return disk_base;
    }

    public void setDisk_base(char[] disk_base) {
        this.disk_base = disk_base;
    }

    public long getVisited() {
        return visited;
    }

    public void setVisited(long visited) {
        this.visited = visited;
    }
}
