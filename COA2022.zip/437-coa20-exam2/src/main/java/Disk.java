import transformer.Transformer;

import java.util.Arrays;


public class Disk {

    public static int DISK_SIZE_B = 64 * 1024 * 1024;      // 磁盘大小 64 MB

    private static Disk diskInstance = new Disk();

    public static char[] disk = new char[DISK_SIZE_B];

    private Disk() {}

    public static Disk getDisk() {
        return diskInstance;
    }

    public char[] read(String eip, int len){
        char[] data = new char[len];
        int startAddr = Integer.parseInt(new Transformer().binaryToInt(eip));
        for (int ptr=0; ptr<len; ptr++) {
            data[ptr] = disk[startAddr + ptr];
        }
        return data;
    }

    public void write(String eip, int len, char []data){
        int startAddr = Integer.parseInt(new Transformer().binaryToInt(eip));
        for (int ptr=0; ptr<len; ptr++) {
            disk[startAddr + ptr] = data[ptr];
        }
    }
}
