package registers;

/**
 * 通用寄存器
 */
public class EAX extends Register {
}
