package memory.cache.cacheReplacementStrategy;

import memory.Memory;
import memory.cache.Cache;

/**
 * TODO 先进先出算法
 */
public class FIFOReplacement implements ReplacementStrategy {
    private static long time = 0L;


    @Override
    public void hit(int rowNO) {

    }

    @Override
    public int replace(int start, int end, char[] addrTag, byte[] input) {
        long longestRow = 1L << 30;
        int line = -1;
        for (int i = start; i <= end; i++) {
            long Row = Cache.getCache().getTimeStamp(i);
            if (Row < longestRow) {
                longestRow = Row;
                line = i;
            }
        }
        if(Cache.getCache().isDirty(line)&& Cache.getCache().isValid(line)){
            Memory.getMemory().write(Cache.getCache().getpAddr(line), 64, Cache.getCache().getData(line));
            Cache.getCache().setDirty(line);
        }
        Cache.getCache().update(line, addrTag, input);
        time += 1;
        Cache.getCache().setTimeStampLRU(line, time);
        return line;
    }

}
