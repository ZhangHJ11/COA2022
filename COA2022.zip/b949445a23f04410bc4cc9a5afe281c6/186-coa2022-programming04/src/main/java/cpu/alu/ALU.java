package cpu.alu;

import util.DataType;

import java.util.Objects;

import static util.Transformer.binaryToInt;
import static util.Transformer.intToBinary;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 */
public class ALU {

    DataType remainderReg;

    /**
     * 判断是否同号
     *
     * @param a
     * @param b
     * @return boolean
     */
    public boolean myjudge(String a, String b) {
        return a.charAt(0) == b.charAt(0);
    }

    public DataType add(DataType src, DataType dest) {
        String s = src.toString();
//        System.out.println(s);
        String d = dest.toString();
//        System.out.println(d);
        StringBuilder a = new StringBuilder("");
        int flag = 0;
        for (int i = 31; i >= 0; i--) {
            if (s.charAt(i) == '1' && d.charAt(i) == '1' && flag == 1) {
                a.insert(0, "1");
                flag = 1;
            } else if (s.charAt(i) == '1' && d.charAt(i) == '1' && flag == 0) {
                a.insert(0, "0");
                flag = 1;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '1' && flag == 1 ||
                    s.charAt(i) == '1' && d.charAt(i) == '0' && flag == 1) {
                a.insert(0, "0");
                flag = 1;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '1' && flag == 0 ||
                    s.charAt(i) == '1' && d.charAt(i) == '0' && flag == 0) {
                a.insert(0, "1");
                flag = 0;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '0' && flag == 0) {
                a.insert(0, "0");
                flag = 0;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '0' && flag == 1) {
                a.insert(0, "1");
                flag = 0;
            }
        }
        DataType ans = new DataType(a.toString());
        return ans;
    }

    /**
     * 返回两个二进制整数的除法结果
     * dest ÷ src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public DataType div(DataType src, DataType dest) {
        String z = "00000000000000000000000000000000";
        DataType zero = new DataType(z);
//        除数装入除数寄存器，被除数符号扩展装入余数、商
        String Y = src.toString();
        String X = dest.toString();
        String nY = Y;
        nY = binaryToInt(Y);
        int t = -Integer.parseInt(nY);
        nY = intToBinary(String.valueOf(t));
        String rec = "";

        if (Objects.equals(Y, z)) {
            throw new ArithmeticException();
        }

        StringBuilder RQ = new StringBuilder(X);
        if (X.charAt(0) == '0') {
            RQ.insert(0, "00000000000000000000000000000000");
        } else if (X.charAt(0) == '1') {
            RQ.insert(0, "11111111111111111111111111111111");
        }

//        System.out.println(RQ);
//        System.out.println(Y);
//        System.out.println(nY);

        DataType tmp_data;
        for (int i = 0; i <= 32; i++) {
            if (i == 0) {
                if (myjudge(X, Y)) {
//                    同号做减法
                    StringBuilder tmp = new StringBuilder(RQ.substring(0, 32));
                    tmp_data = new DataType(tmp.toString());
                    DataType nY_data = new DataType(nY);
                    tmp_data = add(tmp_data, nY_data);
                } else {
//                    异号做加法
                    StringBuilder tmp = new StringBuilder(RQ.substring(0, 32));
                    tmp_data = new DataType(tmp.toString());
                    DataType Y_data = new DataType(Y);
                    tmp_data = add(tmp_data, Y_data);
                }
//                中间余数和Y符号相同
                RQ.replace(0, 32, tmp_data.toString());
                if (myjudge(tmp_data.toString(), Y)) {
                    RQ.insert(64, "1");
                } else {
                    RQ.insert(64, "0");
                }
                rec = RQ.substring(0, 1);
                RQ.delete(0, 1);

//                System.out.println(RQ);

            } else if (i != 32) {
//
                StringBuilder tmp = new StringBuilder(RQ.substring(0, 32));
                tmp_data = new DataType(tmp.toString());
//                同号就减
                if (myjudge(rec, Y)) {
                    DataType nY_data = new DataType(nY);
                    tmp_data = add(tmp_data, nY_data);
                } else {
                    DataType Y_data = new DataType(Y);
                    tmp_data = add(tmp_data, Y_data);
                }
//                结果相同上1
                RQ.replace(0, 32, tmp_data.toString());
                if (myjudge(tmp_data.toString(), Y)) {
                    RQ.insert(64, "1");
                } else {
                    RQ.insert(64, "0");
                }
                rec = RQ.substring(0, 1);
                RQ.delete(0, 1);
//                System.out.println(RQ);
            } else {
//                System.out.println(rec);
//                System.out.println(RQ);
//                System.out.println(Y);
//                System.out.println(nY);

                StringBuilder tmp = new StringBuilder(RQ.substring(0, 32));
                tmp_data = new DataType(tmp.toString());
//                同号就减
                if (myjudge(rec, Y)) {
                    DataType nY_data = new DataType(nY);
                    tmp_data = add(tmp_data, nY_data);
                } else {
                    DataType Y_data = new DataType(Y);
                    tmp_data = add(tmp_data, Y_data);
                }
//                结果相同上1
                RQ.replace(0, 32, tmp_data.toString());
                if (myjudge(tmp_data.toString(), Y)) {
                    RQ.insert(64, "1");
                } else {
                    RQ.insert(64, "0");
                }
                RQ.delete(32, 33);
            }
        }

//        System.out.println(RQ);

        DataType shang = new DataType(RQ.substring(32, 64));
        DataType one = new DataType("00000000000000000000000000000001");
        DataType subone = new DataType("11111111111111111111111111111111");
        if (!myjudge(X, Y))
            shang = add(shang, one);

        DataType rem = new DataType(RQ.substring(0, 32));
        if (!myjudge(rem.toString(), X)) {
            if (myjudge(X, Y)) {
                remainderReg = add(rem, new DataType(Y));
            } else {
                remainderReg = add(rem, new DataType(nY));
            }
        } else {
            remainderReg = rem;
        }

//        System.out.println();
//        System.out.println(shang);
//        System.out.println(remainderReg);

//        解决bug
        if (Objects.equals(remainderReg.toString(), nY)
                || Objects.equals(remainderReg.toString(), Y)) {
            if (myjudge(X, Y)) {
                shang = add(shang, one);
                remainderReg = zero;
            } else {
                shang = add(shang, subone);
                remainderReg = zero;
            }
        }

//        System.out.println();
//        System.out.println(shang);
//        System.out.println(remainderReg);

        return shang;
    }

}
