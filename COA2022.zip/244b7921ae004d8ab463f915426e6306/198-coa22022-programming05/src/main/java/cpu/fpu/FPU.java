package cpu.fpu;

import util.DataType;
import util.IEEE754Float;

import java.util.Objects;

import static util.IEEE754Float.*;

/**
 * floating point unit
 * 执行浮点运算的抽象单元
 * 浮点数精度：使用3位保护位进行计算
 */
public class FPU {

    private final String[][] addCorner = new String[][]{
            {P_ZERO, P_ZERO, P_ZERO},
            {IEEE754Float.N_ZERO, P_ZERO, P_ZERO},
            {P_ZERO, IEEE754Float.N_ZERO, P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.P_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_INF, IEEE754Float.NaN}
    };

    private final String[][] subCorner = new String[][]{
            {P_ZERO, P_ZERO, P_ZERO},
            {IEEE754Float.N_ZERO, P_ZERO, IEEE754Float.N_ZERO},
            {P_ZERO, IEEE754Float.N_ZERO, P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, P_ZERO},
            {IEEE754Float.P_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_INF, IEEE754Float.NaN}
    };

    /**
     * compute the float add of (dest + src)
     */
    public DataType add(DataType src, DataType dest) {
        String s = src.toString();
        String d = dest.toString();
//        NaN
        if (s.matches(IEEE754Float.NaN_Regular) || d.matches(IEEE754Float.NaN_Regular)) {
            return new DataType(IEEE754Float.NaN);
        }
//        0 or Inf
        if (cornerCheck(addCorner, d, s) != null) {
            return new DataType(Objects.requireNonNull(cornerCheck(addCorner, d, s)));
        }
//        one of the op is zero
        if (d.equals(P_ZERO) || d.equals(N_ZERO)) {
            return src;
        }
        if (s.equals(P_ZERO) || s.equals(N_ZERO)) {
            return dest;
        }
//        one of the op is Inf
        if (d.equals(P_INF) || d.equals(N_INF)) {
            return dest;
        }
        if (s.equals(P_INF) || s.equals(N_INF)) {
            return src;
        }

        String s_neg = s.substring(0, 1);
        String s_e = s.substring(1, 9);
        String s_f = s.substring(9, 32);
        String d_neg = d.substring(0, 1);
        String d_e = d.substring(1, 9);
        String d_f = d.substring(9, 32);

        if (Objects.equals(s_e, "00000000")) {
            s_f = "0" + s_f + "000";
            s_e = "00000001";
        } else {
            s_f = "1" + s_f + "000";
        }
        if (Objects.equals(d_e, "00000000")) {
            d_f = "0" + d_f + "000";
            d_e = "00000001";
        } else {
            d_f = "1" + d_f + "000";
        }

//        对齐 ?:每次都rightshift ?:有效值为0
//        0:相等 1：s大 2：d大
        int flag = 0;
        for (int i = 0; i < 8; i++) {
            if (s_e.charAt(i) != d_e.charAt(i)) {
                flag = (s_e.charAt(i) == '1') ? 1 : 2;
                break;
            }
        }

//        System.out.println(flag);

        if (flag == 1) {
            while (!s_e.equals(d_e)) {
                d_e = myadd(d_e, "00000001");
                d_f = rightShift(d_f, 1);
                if (Objects.equals(d_f, "000000000000000000000000000")) {
                    return src;
                }
            }
        } else if (flag == 2) {
            while (!s_e.equals(d_e)) {
                s_e = myadd(s_e, "00000001");
                s_f = rightShift(s_f, 1);
                if (Objects.equals(s_f, "000000000000000000000000000")) {
                    return dest;
                }
            }
        }

//        带符号的有效值相加
//        符号位相同
        if (d_neg.equals(s_neg)) {
            char ans_neg = d_neg.charAt(0);
            String ans_e = d_e;
//            System.out.println(ans_e);
            StringBuilder ans_f = new StringBuilder(myadd(d_f, s_f));
            if (ans_f.length() > 27) {
                ans_f = new StringBuilder(rightShift(ans_f.toString(), 1));
                ans_f.delete(0, 1);
                ans_e = myadd(ans_e, "00000001");
//                ？:正负无穷
            }
            //           规格化 左移有效值 阶值减一
            while (ans_f.charAt(0) != '1') {
                if (ans_e.equals("00000001")) {
                    ans_e = "00000000";
                    break;
                }
                ans_e = myadd(ans_e, "11111111").substring(1);
                ans_f = new StringBuilder(ans_f.substring(1) + "0");
            }
            return new DataType(round(ans_neg, ans_e, ans_f.toString()));
        } else {
            int flag1 = 0;
            char ans_neg;
            String ans_e = d_e;
            StringBuilder ans_f = new StringBuilder("");
            for (int i = 0; i < 27; i++) {
                if (s_f.charAt(i) != d_f.charAt(i)) {
                    flag1 = (s_f.charAt(i) == '1') ? 1 : 2;
                    break;
                }
            }
//            flag==1 s大 判断结果正负
            if (flag1 == 0) {
                return new DataType(P_ZERO);
            } else if (flag1 == 1) {
                ans_neg = s_neg.charAt(0);
            } else {
                ans_neg = d_neg.charAt(0);
            }
//           有效位算数
            ans_f = new StringBuilder(myadd(s_f, mynega(d_f)));
            if (ans_f.length() == 28) {
                ans_f.delete(0, 1);
            } else if (ans_f.length() == 27) {
                ans_f = new StringBuilder(mynega(ans_f.toString()));
            }
//           规格化 左移有效值 阶值减一
            while (ans_f.charAt(0) != '1') {
                if (ans_e.equals("00000001")) {
                    ans_e = "00000000";
                    break;
                }
                ans_e = myadd(ans_e, "11111111").substring(1);
                ans_f = new StringBuilder(ans_f.substring(1) + "0");
            }
            return new DataType(round(ans_neg, ans_e, ans_f.toString()));
        }
    }

    /**
     * compute the float add of (dest - src)
     */
    public DataType sub(DataType src, DataType dest) {
        StringBuilder s = new StringBuilder(src.toString());
        s.replace(0, 1, (s.charAt(0) == '1') ? "0" : "1");
        src = new DataType(s.toString());
        return add(src, dest);
    }


    private String myadd(String a, String b) {
        StringBuilder ans = new StringBuilder();
        int flag = 0;
        for (int i = a.length() - 1; i >= 0; i--) {
            if (a.charAt(i) == '1' && b.charAt(i) == '1' && flag == 1) {
                ans.insert(0, "1");
                flag = 1;
            } else if (a.charAt(i) == '1' && b.charAt(i) == '1' && flag == 0) {
                ans.insert(0, "0");
                flag = 1;
            } else if (a.charAt(i) == '0' && b.charAt(i) == '1' && flag == 1 ||
                    a.charAt(i) == '1' && b.charAt(i) == '0' && flag == 1) {
                ans.insert(0, "0");
                flag = 1;
            } else if (a.charAt(i) == '0' && b.charAt(i) == '1' && flag == 0 ||
                    a.charAt(i) == '1' && b.charAt(i) == '0' && flag == 0) {
                ans.insert(0, "1");
                flag = 0;
            } else if (a.charAt(i) == '0' && b.charAt(i) == '0' && flag == 0) {
                ans.insert(0, "0");
                flag = 0;
            } else if (a.charAt(i) == '0' && b.charAt(i) == '0' && flag == 1) {
                ans.insert(0, "1");
                flag = 0;
            }
        }
        if (flag == 0) {
            return ans.toString();
        } else {
            ans.insert(0, "1");
            return ans.toString();
        }
    }

    private String mynega(String a) {
        StringBuilder result = new StringBuilder("");
        int last = a.length();
        for (int i = a.length() - 1; i >= 0; i--) {
            if (a.charAt(i) == '1') {
                last = i;
                break;
            }
        }
        for (int i = 0; i < last; i++) {
            result.append(a.charAt(i) == '1' ? "0" : "1");
        }
        for (int i = last; i < a.length(); i++) {
            result.append(a.charAt(i) == '1' ? "1" : "0");
        }
        return result.toString();
    }

    private String cornerCheck(String[][] cornerMatrix, String oprA, String oprB) {
        for (String[] matrix : cornerMatrix) {
            if (oprA.equals(matrix[0]) && oprB.equals(matrix[1])) {
                return matrix[2];
            }
        }
        return null;
    }

    /**
     * right shift a num without considering its sign using its string format
     *
     * @param operand to be moved
     * @param n       moving nums of bits
     * @return after moving
     */
    private String rightShift(String operand, int n) {
        StringBuilder result = new StringBuilder(operand);  //保证位数不变
        boolean sticky = false;
        for (int i = 0; i < n; i++) {
            sticky = sticky || result.toString().endsWith("1");
            result.insert(0, "0");
            result.deleteCharAt(result.length() - 1);
        }
        if (sticky) {
            result.replace(operand.length() - 1, operand.length(), "1");
        }
        return result.substring(0, operand.length());
    }

    /**
     * 对GRS保护位进行舍入
     *
     * @param sign    符号位
     * @param exp     阶码
     * @param sig_grs 带隐藏位和保护位的尾数
     * @return 舍入后的结果
     */
    private String round(char sign, String exp, String sig_grs) {
        int grs = Integer.parseInt(sig_grs.substring(24, 27), 2);
        if ((sig_grs.substring(27).contains("1")) && (grs % 2 == 0)) {
            grs++;
        }
        String sig = sig_grs.substring(0, 24); // 隐藏位+23位
        if (grs > 4) {
            sig = oneAdder(sig);
        } else if (grs == 4 && sig.endsWith("1")) {
            sig = oneAdder(sig);
        }

        if (Integer.parseInt(sig.substring(0, sig.length() - 23), 2) > 1) {
            sig = rightShift(sig, 1);
            exp = oneAdder(exp).substring(1);
        }
        if (exp.equals("11111111")) {
            return sign == '0' ? IEEE754Float.P_INF : IEEE754Float.N_INF;
        }

        return sign + exp + sig.substring(sig.length() - 23);
    }

    /**
     * add one to the operand
     *
     * @param operand the operand
     * @return result after adding, the first position means overflow (not equal to the carray to the next) and the remains means the result
     */
    private String oneAdder(String operand) {
        int len = operand.length();
        StringBuilder temp = new StringBuilder(operand);
        temp.reverse();
        int[] num = new int[len];
        for (int i = 0; i < len; i++) num[i] = temp.charAt(i) - '0';  //先转化为反转后对应的int数组
        int bit = 0x0;
        int carry = 0x1;
        char[] res = new char[len];
        for (int i = 0; i < len; i++) {
            bit = num[i] ^ carry;
            carry = num[i] & carry;
            res[i] = (char) ('0' + bit);  //显示转化为char
        }
        String result = new StringBuffer(new String(res)).reverse().toString();
        return "" + (result.charAt(0) == operand.charAt(0) ? '0' : '1') + result;  //注意有进位不等于溢出，溢出要另外判断
    }

}
