package cpu.fpu;

import util.BinaryIntegers;
import util.DataType;
import util.IEEE754Float;
import cpu.alu.ALU;
import util.Transformer;

/**
 * floating point unit
 * 执行浮点运算的抽象单元
 * 浮点数精度：使用3位保护位进行计算
 */
public class FPU {

    private final String[][] mulCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.P_ZERO, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_ZERO, IEEE754Float.NaN}
    };

    private final String[][] divCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
    };


    /**
     * compute the float mul of dest * src
     */
    public DataType mul(DataType src, DataType dest) {
        String s=src.toString();
        String d=dest.toString();

        char signalA=s.charAt(0);
        char signalB=d.charAt(0);
        String expA=s.substring(1,9);
        String expB=d.substring(1,9);
        String mantissaA=s.substring(9,32)+"000";
        String mantissaB=d.substring(9,32)+"000";
        char sign=(signalA==signalB)?'0':'1';
        String exp;
        int e=0,e1=0,e2=0;

        if(s.matches(IEEE754Float.NaN_Regular)||d.matches(IEEE754Float.NaN_Regular)) return new DataType(IEEE754Float.NaN);
        String check=cornerCheck(mulCorner,s,d);
        if(check!=null) return new DataType(check);
        if(s.equals(IEEE754Float.N_ZERO)||s.equals(IEEE754Float.P_ZERO)||d.equals(IEEE754Float.N_ZERO)||d.equals(IEEE754Float.P_ZERO)){
            return new DataType(sign+"0000000000000000000000000000000");
        }
        if(expA.equals("11111111")||expB.equals("11111111")) return new DataType(sign+"1111111100000000000000000000000");
        if(expA.equals("00000000")){
            e1+=1;
            mantissaA="0"+mantissaA;
        }
        else mantissaA="1"+mantissaA;

        if(expB.equals("00000000")){
            e1+=1;
            mantissaB="0"+mantissaB;
        }
        else mantissaB="1"+mantissaB;

        for(int i=0;i<8;i++){
            e1+=(expA.charAt(i)-'0')*Math.pow(2,8-i-1);
            e2+=(expB.charAt(i)-'0')*Math.pow(2,8-i-1);
        }

        e=e1+e2-127;

        String res="000000000000000000000000000";
        int carry;
//        A011 B011
//        000 0011
//        
        for(int i=0;i<27;i++){
            carry=0;
            if(mantissaA.charAt(mantissaA.length()-1)=='1'){
                StringBuilder temp=new StringBuilder();
                for(int j=26;j>=0;j--){
                    int x=res.charAt(j)-'0';
                    int y=mantissaB.charAt(j)-'0';
                    temp.append(x^y^carry);
                    carry=(x&y)|(x&carry)|(y&carry);
                }
                res=temp.reverse()+res.substring(27);
            }
            res=carry+res;//前面添加的是carry而不是0！
            mantissaA=mantissaA.substring(0,mantissaA.length()-1);
        }

        e++;

        while(res.charAt(0)=='0'&&e>0){
            res=res.substring(1)+'0';
            e--;
        }

        while(e<0){
            if(res.equals("000000000000000000000000000000000000000000000000000000"))
                return new DataType(sign+"0000000000000000000000000000000");
            e++;
            res=rightShift(res,1);
        }

        if(e>=255) return new DataType(sign+"1111111100000000000000000000000");
        else if(e==0){
            res=rightShift(res,1);
        }

        exp=Transformer.intToBinary(String.valueOf(e)).substring(24);
        return new DataType(round(sign,exp,res));
    }



        /**
         * compute the float mul of dest / src
         */
    public DataType div(DataType src, DataType dest) {
        String s=src.toString();
        String d=dest.toString();

        if(s.matches(IEEE754Float.NaN_Regular)||d.matches(IEEE754Float.NaN_Regular)) return new DataType(IEEE754Float.NaN);
        String check=cornerCheck(divCorner,s,d);
        if(check!=null) return new DataType(check);

        if(s.equals(BinaryIntegers.ZERO)) throw new ArithmeticException();

        char signalA=s.charAt(0);
        char signalB=d.charAt(0);
        String expA=s.substring(1,9);
        String expB=d.substring(1,9);
        String mantissaA=s.substring(9,32)+"000";
        String mantissaB=d.substring(9,32)+"000";
        char sign=(signalA==signalB)?'0':'1';
        String exp;
        int e=0,e1=0,e2=0;


        if(d.equals(IEEE754Float.P_ZERO)||d.equals(IEEE754Float.N_ZERO)) return new DataType(sign+"0000000000000000000000000000000");


        if(expA.equals("00000000")){
            e1+=1;
            mantissaA="0"+mantissaA;
        }
        else mantissaA="1"+mantissaA;

        if(expB.equals("00000000")){
            e1+=1;
            mantissaB="0"+mantissaB;
        }
        else mantissaB="1"+mantissaB;

        for(int i=0;i<8;i++){
            e1+=(expA.charAt(i)-'0')*Math.pow(2,8-i-1);
            e2+=(expB.charAt(i)-'0')*Math.pow(2,8-i-1);
        }

        e=e2-e1+127;

        StringBuilder res=new StringBuilder();
        for(int i=0;i<27;i++){
            StringBuilder temp=new StringBuilder();
            int carry=1;
            int j=0;
            boolean judge=true;
            for(;j<27;j++){
                if(mantissaB.charAt(j)=='1'&&mantissaA.charAt(j)=='0') break;//注意！
                if(mantissaA.charAt(j)=='1'&&mantissaB.charAt(j)=='0'){
                    judge=false;
                    break;
                }
            }
            if(judge){
                res.append(1);
                for(int k=26;k>=0;k--){
                    int x=mantissaB.charAt(k)-'0';
                    int y=1-(mantissaA.charAt(k)-'0');
                    temp.append(x^y^carry);
                    carry=x&y|x&carry|y&carry;
                }
                mantissaB=temp.reverse().toString();
            }
            else res.append(0);
            mantissaA='0'+mantissaA.substring(0,26);
        }

        exp=Transformer.intToBinary(String.valueOf(e)).substring(24);

        return new DataType(round(sign,exp,res.toString()));
    }


    private String cornerCheck(String[][] cornerMatrix, String oprA, String oprB) {
        for (String[] matrix : cornerMatrix) {
            if (oprA.equals(matrix[0]) &&
                    oprB.equals(matrix[1])) {
                return matrix[2];
            }
        }
        return null;
    }

    /**
     * right shift a num without considering its sign using its string format
     *
     * @param operand to be moved
     * @param n       moving nums of bits
     * @return after moving
     */
    private String rightShift(String operand, int n) {
        StringBuilder result = new StringBuilder(operand);  //保证位数不变
        boolean sticky = false;
        for (int i = 0; i < n; i++) {
            sticky = sticky || result.toString().endsWith("1");
            result.insert(0, "0");
            result.deleteCharAt(result.length() - 1);
        }
        if (sticky) {
            result.replace(operand.length() - 1, operand.length(), "1");
        }
        return result.substring(0, operand.length());
    }

    /**
     * 对GRS保护位进行舍入
     *
     * @param sign    符号位
     * @param exp     阶码
     * @param sig_grs 带隐藏位和保护位的尾数
     * @return 舍入后的结果
     */
    private String round(char sign, String exp, String sig_grs) {
        int grs = Integer.parseInt(sig_grs.substring(24, 27), 2);
        if ((sig_grs.substring(27).contains("1")) && (grs % 2 == 0)) {
            grs++;
        }
        String sig = sig_grs.substring(0, 24); // 隐藏位+23位
        if (grs > 4 || (grs == 4 && sig.endsWith("1"))) {
            sig = oneAdder(sig);
            if (sig.charAt(0) == '1') {
                exp = oneAdder(exp).substring(1);
                sig = sig.substring(1);
            }
        }

        if (Integer.parseInt(sig.substring(0, sig.length() - 23), 2) > 1) {
            sig = rightShift(sig, 1);
            exp = oneAdder(exp).substring(1);
        }
        if (exp.equals("11111111")) {
            return sign == '0' ? IEEE754Float.P_INF : IEEE754Float.N_INF;
        }

        return sign + exp + sig.substring(sig.length() - 23);
    }

    /**
     * add one to the operand
     *
     * @param operand the operand
     * @return result after adding, the first position means overflow (not equal to the carray to the next) and the remains means the result
     */
    private String oneAdder(String operand) {
        int len = operand.length();
        StringBuffer temp = new StringBuffer(operand);
        temp = temp.reverse();
        int[] num = new int[len];
        for (int i = 0; i < len; i++) num[i] = temp.charAt(i) - '0';  //先转化为反转后对应的int数组
        int bit = 0x0;
        int carry = 0x1;
        char[] res = new char[len];
        for (int i = 0; i < len; i++) {
            bit = num[i] ^ carry;
            carry = num[i] & carry;
            res[i] = (char) ('0' + bit);  //显示转化为char
        }
        String result = new StringBuffer(new String(res)).reverse().toString();
        return "" + (result.charAt(0) == operand.charAt(0) ? '0' : '1') + result;  //注意有进位不等于溢出，溢出要另外判断
    }
}