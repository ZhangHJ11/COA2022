package cpu.alu;

import util.DataType;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 */
public class ALU {

    /**
     * 返回两个二进制整数的和
     * dest + src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public DataType add(DataType src, DataType dest) {
        int c=0;
        int s1,d1;
        String s = src.toString();
        String d = dest.toString();
        StringBuilder ans = new StringBuilder();
        for(int i=s.length()-1;i>=0;i--){
            s1 = s.charAt(i) - '0';
            d1 = d.charAt(i) - '0';
            ans.append(c ^ s1 ^ d1);
            c = (s1 & d1) | (c & d1) | (s1 & c);
        }
        return new DataType(ans.reverse().toString());
    }

    /**
     * 返回两个二进制整数的差
     * dest - src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public DataType sub(DataType src, DataType dest) {
        int c=1;
        int s1,d1;
        String s = src.toString();
        String d = dest.toString();
        StringBuilder ans = new StringBuilder();
        for(int i=s.length()-1;i>=0;i--){
            s1 = 1 - (s.charAt(i) - '0');
            d1 = d.charAt(i) - '0';
            ans.append(c ^ s1 ^ d1);
            c = (s1 & d1) | (c & d1) | (s1 & c);

        }
        return new DataType(ans.reverse().toString());
    }


}
