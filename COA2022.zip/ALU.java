package cpu.alu;

import util.DataType;

import java.util.Objects;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 */
public class ALU {

    DataType remainderReg;

    private DataType neg(DataType src) {
        String operand = src.toString();
        StringBuilder tmp = new StringBuilder();
        for (int i = 31; i != -1; i--) tmp.append((operand.charAt(i) == '1') ? '0' : '1');
        return add(new DataType(tmp.reverse().toString()), new DataType("00000000000000000000000000000001"));
    }

    public DataType add(DataType src, DataType dest) {
        String operand_1 = src.toString();
        String operand_2 = dest.toString();
        StringBuilder res = new StringBuilder();
        boolean c = false;
        for (int i = 31; i != -1; i--) {
            char chr1 = operand_1.charAt(i), chr2 = operand_2.charAt(i);
            if (c & (chr1 == '1') & (chr2 == '1')) res.append("1");
            else if ((c & (chr1 == '1')) | (c & (chr2 == '1')) | ((chr1 == '1') & (chr2 == '1'))) {
                c = true;
                res.append('0');
            } else if (c | (chr1 == '1') | (chr2 == '1')) {
                c = false;
                res.append('1');
            } else res.append('0');
        }
        return new DataType(res.reverse().toString());
    }


    /**
     * 返回两个二进制整数的除法结果
     * dest ÷ src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public DataType div(DataType src, DataType dest) {
        if (src.toString().equals("00000000000000000000000000000000")) throw new ArithmeticException();
        String x = dest.toString(), y = src.toString();
        DataType negy = neg(src), ans;
        boolean p = false;
        StringBuilder r = new StringBuilder(x);
        r.insert(0, x.charAt(0) == '0' ? "00000000000000000000000000000000" : "11111111111111111111111111111111");
        r.replace(0, 32, add(new DataType(r.substring(0, 32)), x.charAt(0) == y.charAt(0) ? negy : src).toString());
        p = r.charAt(0) == y.charAt(0);
        for (int i = 1; i <= 32; i++) {
            r.delete(0, 1);
            r.append(p ? "1" : "0");
            r.replace(0, 32, add(new DataType(r.substring(0, 32)), p ? negy : src).toString());
            p = r.charAt(0) == y.charAt(0);
        }
        remainderReg = new DataType(r.substring(0, 32));
        if (remainderReg.toString().charAt(0) != x.charAt(0))
            remainderReg = add(remainderReg, x.charAt(0) == y.charAt(0) ? src : negy);
        StringBuilder res = new StringBuilder(r.substring(32));
        res.delete(0, 1);
        res.append(p ? "1" : "0");
        ans = x.charAt(0) != y.charAt(0) ? add(new DataType(res.toString()), new DataType("00000000000000000000000000000001")) : new DataType(res.toString());
        if (Objects.equals(src.toString(), remainderReg.toString())) {
            remainderReg = new DataType("00000000000000000000000000000000");
            return add(ans, new DataType("00000000000000000000000000000001"));
        } else if (Objects.equals(src.toString(), neg(remainderReg).toString())) {
            remainderReg = new DataType("00000000000000000000000000000000");
            return add(ans, new DataType("11111111111111111111111111111111"));
        }
        return ans;

//        if(x[0]==y[0]) r=x-y;
//        else r=x+y;
//        if(r[0]==y[0]) p=1;
//        else p=0;
//
//        for(i=1~32) {
//            r<<=1;
//            r+=p;
//            if(r[0]==y[0]) r-y,p=1;
//            else r+y,p=0;
//        }
//        res<<=1;
//        res+=p;
//        if(x[0]!=y[0]) res+1;
//
//        if(remainderReg[0]!=x[0]) {
//            if(x[0]==y[0]) remainderReg+y;
//            else remainderReg-y;
//        }

//        return null;
    }

}
