package cpu.alu;

import util.DataType;
import util.Transformer;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 */
public class ALU {

    /**
     * 返回两个二进制整数的和
     * dest + src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public DataType add(DataType src, DataType dest) {
        String s = src.toString();
//        System.out.println(s);
        String d = dest.toString();
//        System.out.println(d);
        String a = new String("");
        int flag = 0;
        for (int i = 31; i >= 0; i--) {
            if (s.charAt(i) == '1' && d.charAt(i) == '1' && flag == 1) {
                a = "1" + a;
                flag = 1;
            } else if (s.charAt(i) == '1' && d.charAt(i) == '1' && flag == 0) {
                a = "0" + a;
                flag = 1;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '1' && flag == 1 ||
                    s.charAt(i) == '1' && d.charAt(i) == '0' && flag == 1) {
                a = "0" + a;
                flag = 1;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '1' && flag == 0 ||
                    s.charAt(i) == '1' && d.charAt(i) == '0' && flag == 0) {
                a = "1" + a;
                flag = 0;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '0' && flag == 0) {
                a = "0" + a;
                flag = 0;
            } else if (s.charAt(i) == '0' && d.charAt(i) == '0' && flag == 1) {
                a = "1" + a;
                flag = 0;
            }
        }
//        System.out.println(a);
        DataType ans = new DataType(a);
        return ans;
    }

    /**
     * 返回两个二进制整数的差
     * dest - src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public DataType sub(DataType src, DataType dest) {
        // dest-src
        String s = src.toString();
        s = Transformer.negation(s);
        s = Transformer.oneAdder(s);
        s = s.substring(1);
        DataType ssrc = new DataType(s);
        DataType ans = new DataType(add(dest,ssrc).toString());
//        System.out.println(s);
        return ans;
    }

}
