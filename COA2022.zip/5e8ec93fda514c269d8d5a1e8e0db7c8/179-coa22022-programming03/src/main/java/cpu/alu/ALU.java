package cpu.alu;


import util.DataType;

/**
 * Arithmetic Logic Unit
 * ALU封装类
 */
public class ALU {

    /**
     * 返回两个二进制整数的乘积(结果低位截取后32位)
     * dest * src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public DataType mul(DataType src, DataType dest) {
        String s = src.toString();
        String d = dest.toString();
        StringBuilder ans = new StringBuilder("00000000000000000000000000000000" + s + "0");
        int len = ans.length();
        for(int i=0;i<32;i++){
            if(ans.charAt(len-1) == '0' && ans.charAt(len-2) == '1'){
                ans.replace(0,32,sub(d,ans.substring(0,32)));
            } else if (ans.charAt(len-1) == '1' && ans.charAt(len-2) == '0') {
                ans.replace(0,32,add(d,ans.substring(0,32)));
            }
            ans = new StringBuilder(ans.charAt(0) + ans.substring(0,len-1));
        }
        return new DataType(ans.toString().substring(32,64));
    }

    /**
     * 返回两个二进制整数的和
     * dest + src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public String add(String src, String dest) {
        int c=0;
        int s1,d1;
        String s = src.toString();
        String d = dest.toString();
        StringBuilder ans = new StringBuilder();
        for(int i=s.length()-1;i>=0;i--){
            s1 = s.charAt(i) - '0';
            d1 = d.charAt(i) - '0';
            ans.append(c ^ s1 ^ d1);
            c = (s1 & d1) | (c & d1) | (s1 & c);
        }
        return ans.reverse().toString();
    }

    /**
     * 返回两个二进制整数的差
     * dest - src
     *
     * @param src  32-bits
     * @param dest 32-bits
     * @return 32-bits
     */
    public String sub(String src, String dest) {
        int c=1;
        int s1,d1;
        String s = src.toString();
        String d = dest.toString();
        StringBuilder ans = new StringBuilder();
        for(int i=s.length()-1;i>=0;i--){
            s1 = 1 - (s.charAt(i) - '0');
            d1 = d.charAt(i) - '0';
            ans.append(c ^ s1 ^ d1);
            c = (s1 & d1) | (c & d1) | (s1 & c);

        }
        return ans.reverse().toString();
    }

}
