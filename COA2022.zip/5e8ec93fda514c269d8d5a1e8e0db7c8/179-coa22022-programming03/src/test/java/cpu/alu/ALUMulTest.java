package cpu.alu;

import org.junit.Test;
import util.DataType;
import util.Transformer;

import static org.junit.Assert.assertEquals;

public class ALUMulTest {

	private final ALU alu = new ALU();
	private DataType src;
	private DataType dest;
	private DataType result;

	@Test
	public void MulTest1() {
		src = new DataType("00000000000000000000000000001010");
		dest = new DataType("00000000000000000000000000001010");
		result = alu.mul(src, dest);
		assertEquals("00000000000000000000000001100100", result.toString());
	}

	@Test
	public void test2(){
		for(int i = 1;i<=10;i++){
			for(int j = 1;j<=10;j++){
				src = new DataType(Transformer.intToBinary(String.valueOf(i)));
				dest = new DataType(Transformer.intToBinary(String.valueOf(j)));
				result = alu.mul(src, dest);
				assertEquals(Transformer.intToBinary(String.valueOf(i*j)),result.toString());
			}
		}
	}
}
