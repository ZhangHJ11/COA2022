package cpu.fpu;

//import jdk.jfr.internal.consumer.OngoingStream;
import util.DataType;
import util.IEEE754Float;
import util.Transformer;

import java.nio.ReadOnlyBufferException;
import java.util.Objects;

import static util.Transformer.binaryToInt;
import static util.Transformer.intToBinary;

/**
 * floating point unit
 * 执行浮点运算的抽象单元
 * 浮点数精度：使用3位保护位进行计算
 */
public class FPU {

    private final String[][] mulCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.P_ZERO, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_ZERO, IEEE754Float.NaN}
    };

    private final String[][] divCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.NaN},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.P_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
    };

    private DataType mulCheck(DataType src,DataType dest) {
        String x=src.toString(),y=dest.toString(),z=cornerCheck(mulCorner,x,y);
        if (x.matches(IEEE754Float.NaN_Regular)||y.matches(IEEE754Float.NaN_Regular)) return new DataType(IEEE754Float.NaN);
        if(z!=null) return new DataType(z);
        boolean sym=(x.charAt(0)=='1')^(y.charAt(0)=='1');
        if(Objects.equals(x,IEEE754Float.P_ZERO)||Objects.equals(x,IEEE754Float.N_ZERO)||Objects.equals(y,IEEE754Float.P_ZERO)||Objects.equals(y,IEEE754Float.N_ZERO)) return new DataType(sym?IEEE754Float.N_ZERO:IEEE754Float.P_ZERO);
        if(Objects.equals(x,IEEE754Float.P_INF)||Objects.equals(y,IEEE754Float.P_INF)||Objects.equals(x,IEEE754Float.N_INF)||Objects.equals(y,IEEE754Float.N_INF)) return new DataType(sym?IEEE754Float.N_INF:IEEE754Float.P_INF);
        return null;
    }

    private DataType divCheck(DataType src,DataType dest) {
        String x=src.toString(),y=dest.toString(),z=cornerCheck(divCorner,x,y);
        if (x.matches(IEEE754Float.NaN_Regular)||y.matches(IEEE754Float.NaN_Regular)) return new DataType(IEEE754Float.NaN);
        if(z!=null) return new DataType(z);
        boolean sym=(x.charAt(0)=='1')^(y.charAt(0)=='1');
        if(Objects.equals(y,IEEE754Float.N_ZERO)||Objects.equals(y,IEEE754Float.P_ZERO)||Objects.equals(x,IEEE754Float.P_INF)||Objects.equals(x,IEEE754Float.N_INF)) return new DataType(sym?IEEE754Float.N_ZERO:IEEE754Float.P_ZERO);
        if(Objects.equals(x,IEEE754Float.P_ZERO)||Objects.equals(x,IEEE754Float.N_ZERO)) throw new ArithmeticException();
        if(Objects.equals(y,IEEE754Float.P_INF)||Objects.equals(y,IEEE754Float.N_INF)) return new DataType(sym?IEEE754Float.N_INF:IEEE754Float.P_INF);
        return null;
    }

    private String adder(String operand_1,String operand_2) {
        int length=operand_1.length()-1;
        StringBuilder res=new StringBuilder();
        boolean c=false;
        for(int i=length;i!=-1;i--) {
            char chr1=operand_1.charAt(i),chr2=operand_2.charAt(i);
            if(c&(chr1=='1')&(chr2=='1')) res.append("1");
            else if((c&(chr1=='1'))|(c&(chr2=='1'))|((chr1=='1')&(chr2=='1'))) {
                c=true;
                res.append('0');
            }
            else if(c|(chr1=='1')|(chr2=='1')) {
                c=false;
                res.append('1');
            }
            else res.append('0');
        }
        return (c?"1":"0")+res.reverse();
    }

    private String multer(String operand_1,String operand_2) {
        StringBuilder ans=new StringBuilder("000000000000000000000000000");
        for(int i=26;i>=0;i--) {
            if(operand_2.charAt(i)=='1') ans.replace(0,24,adder(ans.substring(0,24),operand_1));
            else ans.insert(0,"0");
        }
        return ans.toString();
    }

    private String neg(String src) {
        StringBuilder tmp=new StringBuilder();
        for(int i=src.length()-1;i!=-1;i--) tmp.append((src.charAt(i)=='1')?'0':'1');
        return adder(tmp.reverse().toString(),"0000000000000000000000000001").substring(1);
    }

    private String diver(String operand_1,String operand_2) {
        String x="0"+operand_1,y="0"+operand_2;
        String negy=neg(y);
        StringBuilder ans=new StringBuilder(x+"000000000000000000000000000");
//        System.out.println(x+"+");
//        System.out.println(negy);
        ans.replace(0,28,adder(x,negy).substring(1));
//        System.out.println("f"+ans);
        boolean flag=ans.charAt(0)=='1';
        ans.append(flag?"0":"1");
//        System.out.println(ans);

//        System.out.println(y+"negy"+negy);
        for(int i=1;i<=26;i++) {
//            System.out.println(ans);
            ans.delete(0,1);
//            System.out.println(ans);
            ans.replace(0,28,adder(ans.substring(0,28),flag?y:negy).substring(1));
//            System.out.println(ans);
            flag=(ans.charAt(0)=='1');
            ans.append(flag?"0":"1");
        }
//        System.out.println(x+" "+y+" "+ans);
        return ans.substring(29);
    }

    /**
     * compute the float mul of dest * src
     */
    public DataType mul(DataType src, DataType dest) {
        DataType ck_res=mulCheck(src,dest);
        if(ck_res!=null) return ck_res;
        String x=src.toString(),y=dest.toString(),
                ex=x.startsWith("00000000", 1)?"00000001":x.substring(1,9),
                ey=y.startsWith("00000000", 1)?"00000001":y.substring(1,9),
                nx= new StringBuilder(x.substring(9)).insert(0,x.startsWith("00000000",1)?'0':'1') +"000",
                ny= new StringBuilder(y.substring(9)).insert(0,y.startsWith("00000000",1)?'0':'1') +"000";

        boolean f=(x.charAt(0)=='1')^(y.charAt(0)=='1');
        String res=multer(nx,ny);
//        String exp=adder(adder(ex,ey).substring(1),"10000001").substring(1);

        int exp=Integer.parseInt(Transformer.binaryToInt(ex))+Integer.parseInt(Transformer.binaryToInt(ey))-127+1;
//        System.out.println();
//        System.out.println(f+" "+exp+" "+res);

        while (res.startsWith("0") && exp>0) {
            res= (res+"0").substring(1);
            exp--;
        }
        while (res.substring(0,27).contains("1") && exp<0) {
            res=rightShift(res,1);
            exp++;
        }

        String e=Transformer.intToBinary(String.valueOf(exp)).substring(24);
        if (exp>=255) {
            return new DataType(f?IEEE754Float.N_INF:IEEE754Float.P_INF);
        } else if (exp<0) {
            return new DataType(f?IEEE754Float.N_ZERO:IEEE754Float.P_ZERO);
        } else if(exp == 0) {
            res=rightShift(res,1);
            return new DataType(round(f?'1':'0',e,res));
        } else {
            return new DataType(round(f?'1':'0',e,res));
        }



        /*if(res.startsWith("1")) {
            exp=oneAdder(exp).substring(1);
            res=rightShift(res,1).substring(1);
        }
        else if(!Objects.equals(exp,"00000000")) res=res.substring(1);

        if(ex.startsWith("0")&&ey.startsWith("0")&&exp.startsWith("1")) {
            while(!Objects.equals(exp,"00000000")) {
                exp=oneAdder(exp).substring(1);
                res=rightShift(res,1);
            }
            if(!res.substring(0,24).contains("1")) return new DataType(f?IEEE754Float.N_ZERO:IEEE754Float.P_ZERO);
        }
        if(ex.startsWith("1")&&ey.startsWith("1")&&exp.startsWith("0")||Objects.equals("exp","11111111")) return new DataType(f?IEEE754Float.N_INF:IEEE754Float.P_INF);

        if(res.startsWith("0")&&Objects.equals(exp,"00000001")) exp="00000000";
//        while(res.length()>27&&res.startsWith("0")) {
//            if(Objects.equals(exp,"00000001")||Objects.equals(exp,"00000000")) {
//                exp="00000000";
//                while(res.length()>27) res=rightShift(res,1).substring(1);
//                System.out.println(res);
//                break;
//            }
////            if(Objects.equals(exp,"00000000")) {
////
////            }
//            res=res.substring(1);
//            exp=sucker(exp);
//        }
//        while(res.length()>27) res=rightShift(res,1).substring(1);
        */
//        System.out.println(f+" "+exp+" "+res);
//
//        return new DataType(round(f?'1':'0',exp,res));
    }


    /**
     * compute the float mul of dest / src
     */
    public DataType div(DataType src, DataType dest) {
        DataType ck_res=divCheck(src,dest);

//        System.out.println(src);
//        System.out.println(dest);

        if(ck_res!=null) return ck_res;
        String x=src.toString(),y=dest.toString(),
                ex=x.startsWith("00000000", 1)?"00000001":x.substring(1,9),
                ey=y.startsWith("00000000", 1)?"00000001":y.substring(1,9),
                nx= new StringBuilder(x.substring(9)).insert(0,x.startsWith("00000000",1)?'0':'1') +"000",
                ny= new StringBuilder(y.substring(9)).insert(0,y.startsWith("00000000",1)?'0':'1') +"000";

        boolean f=(x.charAt(0)=='1')^(y.charAt(0)=='1');
        String res=diver(ny,nx);

//        System.out.println(ny);
//        System.out.println(nx);
//        System.out.println(res);

        int exp=-Integer.parseInt(binaryToInt(ex))+Integer.parseInt(binaryToInt(ey))+127;
        String e=intToBinary(String.valueOf(exp)).substring(24);

        return new DataType(round(f?'1':'0',e,res));
    }


    private String cornerCheck(String[][] cornerMatrix, String oprA, String oprB) {
        for (String[] matrix : cornerMatrix) {
            if (oprA.equals(matrix[0]) &&
                    oprB.equals(matrix[1])) {
                return matrix[2];
            }
        }
        return null;
    }

    /**
     * right shift a num without considering its sign using its string format
     *
     * @param operand to be moved
     * @param n       moving nums of bits
     * @return after moving
     */
    private String rightShift(String operand, int n) {
        StringBuilder result = new StringBuilder(operand);  //保证位数不变
        boolean sticky = false;
        for (int i = 0; i < n; i++) {
            sticky = sticky || result.toString().endsWith("1");
            result.insert(0, "0");
            result.deleteCharAt(result.length() - 1);
        }
        if (sticky) {
            result.replace(operand.length() - 1, operand.length(), "1");
        }
        return result.substring(0, operand.length());
    }

    /**
     * 对GRS保护位进行舍入
     *
     * @param sign    符号位
     * @param exp     阶码
     * @param sig_grs 带隐藏位和保护位的尾数
     * @return 舍入后的结果
     */
    private String round(char sign, String exp, String sig_grs) {
        int grs = Integer.parseInt(sig_grs.substring(24, 27), 2);
        if ((sig_grs.substring(27).contains("1")) && (grs % 2 == 0)) {
            grs++;
        }
        String sig = sig_grs.substring(0, 24); // 隐藏位+23位
        if (grs > 4 || (grs == 4 && sig.endsWith("1"))) {
            sig = oneAdder(sig);
            if (sig.charAt(0) == '1') {
                exp = oneAdder(exp).substring(1);
                sig = sig.substring(1);
            }
        }

        if (Integer.parseInt(sig.substring(0, sig.length() - 23), 2) > 1) {
            sig = rightShift(sig, 1);
            exp = oneAdder(exp).substring(1);
        }
        if (exp.equals("11111111")) {
            return sign == '0' ? IEEE754Float.P_INF : IEEE754Float.N_INF;
        }

        return sign + exp + sig.substring(sig.length() - 23);
    }

    /**
     * add one to the operand
     *
     * @param operand the operand
     * @return result after adding, the first position means overflow (not equal to the carray to the next) and the remains means the result
     */
    private String oneAdder(String operand) {
        int len = operand.length();
        StringBuffer temp = new StringBuffer(operand);
        temp = temp.reverse();
        int[] num = new int[len];
        for (int i = 0; i < len; i++) num[i] = temp.charAt(i) - '0';  //先转化为反转后对应的int数组
        int bit = 0x0;
        int carry = 0x1;
        char[] res = new char[len];
        for (int i = 0; i < len; i++) {
            bit = num[i] ^ carry;
            carry = num[i] & carry;
            res[i] = (char) ('0' + bit);  //显示转化为char
        }
        String result = new StringBuffer(new String(res)).reverse().toString();
        return "" + (result.charAt(0) == operand.charAt(0) ? '0' : '1') + result;  //注意有进位不等于溢出，溢出要另外判断
    }

}
