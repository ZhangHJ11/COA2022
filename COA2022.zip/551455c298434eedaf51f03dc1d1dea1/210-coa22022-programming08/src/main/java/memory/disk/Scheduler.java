package memory.disk;

import java.util.Arrays;

public class Scheduler {

    /**
     * 先来先服务算法
     *
     * @param start   磁头初始位置
     * @param request 请求访问的磁道号
     * @return 平均寻道长度
     */
    public double FCFS(int start, int[] request) {
        double sum = 0;
        for (int i : request) {
            sum += Math.abs(start - i);
            start = i;
        }
        return sum / request.length;
    }

    /**
     * 最短寻道时间优先算法
     *
     * @param start   磁头初始位置
     * @param request 请求访问的磁道号
     * @return 平均寻道长度
     */
    public double SSTF(int start, int[] request) {
        double sum = 0;
        for (int i = 0; i < request.length; i++) {
            int index = 0;
            for (int j = 0; j < request.length; j++) {
                if (Math.abs(start - request[index]) > Math.abs(start - request[j])) {
                    index = j;
                }
            }
            sum += Math.abs(start - request[index]);
            start = request[index];
            request[index] = 1 << 10;
        }
        return sum / request.length;
    }

    /**
     * 扫描算法
     *
     * @param start     磁头初始位置
     * @param request   请求访问的磁道号
     * @param direction 磁头初始移动方向，true表示磁道号增大的方向，false表示磁道号减小的方向
     * @return 平均寻道长度
     */
    public double SCAN(int start, int[] request, boolean direction) {
        int min = 1 << 10;
        for (int i : request) {
            if (min > i) {
                min = i;
            }
        }
        int max = 0;
        for (int i : request) {
            if (max < i) {
                max = i;
            }
        }
        if (direction) {
            if (min >= start) return (double) (max - start) / request.length;
            else return (double) (255 - start + 255 - min) / request.length;
        } else {
            if (max <= start) return (double) (start - min) / request.length;
            else return (double) (start + max) / request.length;
        }

    }

}
