package cpu.fpu;

import util.DataType;
import util.IEEE754Float;
import util.Transformer;

/**
 * floating point unit
 * 执行浮点运算的抽象单元
 * 浮点数精度：使用3位保护位进行计算
 */
public class FPU {

    private final String[][] addCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.P_INF, IEEE754Float.N_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.P_INF, IEEE754Float.NaN}
    };

    private final String[][] subCorner = new String[][]{
            {IEEE754Float.P_ZERO, IEEE754Float.P_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.P_ZERO, IEEE754Float.N_ZERO},
            {IEEE754Float.P_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.N_ZERO, IEEE754Float.N_ZERO, IEEE754Float.P_ZERO},
            {IEEE754Float.P_INF, IEEE754Float.P_INF, IEEE754Float.NaN},
            {IEEE754Float.N_INF, IEEE754Float.N_INF, IEEE754Float.NaN}
    };

    /**
     * compute the float add of (dest + src)
     */
    public DataType add(DataType src, DataType dest) {
        String s=src.toString();
        String d=dest.toString();
        if(s.matches(IEEE754Float.NaN_Regular)||d.matches(IEEE754Float.NaN_Regular)) return new DataType(IEEE754Float.NaN);
        String check=cornerCheck(addCorner,s,d);
        if(check!=null) return new DataType(check);
        if(s.equals("00000000000000000000000000000000")) return dest;
        else if(d.equals("00000000000000000000000000000000")) return src;

        char signA=s.charAt(0);
        char signB=d.charAt(0);
        char sign='0';
        String expA=s.substring(1,9);
        String expB=d.substring(1,9);
        String exp;
        String mantissaA=s.substring(9)+"000";
        String mantissaB=d.substring(9)+"000";
        String mantissa;

        int e1=0;
        int e2=0;
        int e=e1;

        if(expA.equals("11111111")) return src;
        else if(expB.equals("11111111")) return dest;

        if(expA.equals("00000000")){
            e1=1;
            mantissaA="0"+mantissaA;
        }
        else mantissaA="1"+mantissaA;
        if(expB.equals("00000000")){
            e2=1;
            mantissaB="0"+mantissaB;
        }
        else mantissaB="1"+mantissaB;


        for(int i=0;i<8;i++){
            e1+=(expA.charAt(i)-'0')*Math.pow(2,8-i-1);
            e2+=(expB.charAt(i)-'0')*Math.pow(2,8-i-1);
        }
        int diff=e1-e2;
        if(diff>0){
            e=e1;
            mantissaB=rightShift(mantissaB,diff);
        }
        else{
            e=e2;
            mantissaA=rightShift(mantissaA,Math.abs(diff));
        }

        StringBuilder m=new StringBuilder();
        int carry=0;
        if(signA==signB){
            sign=signA;
            for(int i=26;i>=0;i--){
                int x=mantissaA.charAt(i)-'0';
                int y=mantissaB.charAt(i)-'0';
                m.append(x^y^carry);
                carry=(x&y)|(x&carry)|(y&carry);
            }
        }
        else {
            if(diff>0) sign=signA;  
            else if(diff<0) sign=signB;
            else {
                for (int i = 0; i < 27; i++) {
                    if (mantissaA.charAt(i) == '1' && mantissaB.charAt(i) == '0') {
                        sign = signA;
                        break;
                    } else if (mantissaB.charAt(i) == '1' && mantissaA.charAt(i) == '0') {
                        sign = signB;
                        break;
                    }
                }
            }
            String a;
            String b;
            if(signA=='1'){
                a=mantissaB;
                b=mantissaA;
            }
            else {
                a=mantissaA;
                b=mantissaB;
            }
            carry=1;
            for(int i=26;i>=0;i--){
                int x=a.charAt(i)-'0';
                int y=1-(b.charAt(i)-'0');
                m.append(x^y^carry);
                carry=(x&y)|(x&carry)|(y&carry);
            }
        }

        mantissa=m.reverse().toString();
        if(signA==signB){
            if(carry==1){
                e++;
                mantissa='1'+mantissa.substring(0,26);
            }
            if(e==255) return new DataType(sign+"1111111100000000000000000000000");

            while(mantissa.charAt(0)=='0'){
                mantissa=mantissa.substring(1)+'0';
                e--;

                if(e==0){
                    mantissa='0'+mantissa.substring(0,26);
                    break;
                }
            }
        }
        else {
            if(carry==0){
                mantissa=Transformer.negation(mantissa);
                mantissa=addOne(mantissa);
            }
            while(mantissa.charAt(0)=='0'){
                mantissa=mantissa.substring(1)+'0';
                e--;

                if(e==0){
                    mantissa='0'+mantissa.substring(0,26);
                    break;
                }
            }
        }

        exp=Transformer.intToBinary(String.valueOf(e)).substring(24);

        return new DataType(round(sign,exp,mantissa));
    }

    /**
     * compute the float add of (dest - src)
     */
    public DataType sub(DataType src, DataType dest) {
        String s=src.toString();
        String d=dest.toString();
        s=(s.charAt(0)=='0'?'1':'0')+s.substring(1);
        return add(dest,new DataType(s));
    }

    public String addOne(String num){
        int carry=1;
        StringBuilder res=new StringBuilder();
        for(int i=num.length()-1;i>=0;i--){
            int x=num.charAt(i)-'0';
            res.append(x^carry);
            carry=x&carry;
        }
        return res.reverse().toString();
    }

    private String cornerCheck(String[][] cornerMatrix, String oprA, String oprB) {
        for (String[] matrix : cornerMatrix) {
            if (oprA.equals(matrix[0]) && oprB.equals(matrix[1])) {
                return matrix[2];
            }
        }
        return null;
    }

    /**
     * right shift a num without considering its sign using its string format
     *
     * @param operand to be moved
     * @param n       moving nums of bits
     * @return after moving
     */
    private String rightShift(String operand, int n) {
        StringBuilder result = new StringBuilder(operand);  //保证位数不变
        boolean sticky = false;
        for (int i = 0; i < n; i++) {
            sticky = sticky || result.toString().endsWith("1");
            result.insert(0, "0");
            result.deleteCharAt(result.length() - 1);
        }
        if (sticky) {
            result.replace(operand.length() - 1, operand.length(), "1");
        }
        return result.substring(0, operand.length());
    }

    /**
     * 对GRS保护位进行舍入
     *
     * @param sign    符号位
     * @param exp     阶码
     * @param sig_grs 带隐藏位和保护位的尾数
     * @return 舍入后的结果
     */
    private String round(char sign, String exp, String sig_grs) {
        int grs = Integer.parseInt(sig_grs.substring(24, 27), 2);
        if ((sig_grs.substring(27).contains("1")) && (grs % 2 == 0)) {
            grs++;
        }
        String sig = sig_grs.substring(0, 24); // 隐藏位+23位
        if (grs > 4) {
            sig = oneAdder(sig);
        } else if (grs == 4 && sig.endsWith("1")) {
            sig = oneAdder(sig);
        }

        if (Integer.parseInt(sig.substring(0, sig.length() - 23), 2) > 1) {
            sig = rightShift(sig, 1);
            exp = oneAdder(exp).substring(1);
        }
        if (exp.equals("11111111")) {
            return sign == '0' ? IEEE754Float.P_INF : IEEE754Float.N_INF;
        }

        return sign + exp + sig.substring(sig.length() - 23);
    }

    /**
     * add one to the operand
     *
     * @param operand the operand
     * @return result after adding, the first position means overflow (not equal to the carray to the next) and the remains means the result
     */
    private String oneAdder(String operand) {
        int len = operand.length();
        StringBuilder temp = new StringBuilder(operand);
        temp.reverse();
        int[] num = new int[len];
        for (int i = 0; i < len; i++) num[i] = temp.charAt(i) - '0';  //先转化为反转后对应的int数组
        int bit = 0x0;
        int carry = 0x1;
        char[] res = new char[len];
        for (int i = 0; i < len; i++) {
            bit = num[i] ^ carry;
            carry = num[i] & carry;
            res[i] = (char) ('0' + bit);  //显示转化为char
        }
        String result = new StringBuffer(new String(res)).reverse().toString();
        return "" + (result.charAt(0) == operand.charAt(0) ? '0' : '1') + result;  //注意有进位不等于溢出，溢出要另外判断
    }
}

//    //处理边界情况
//    String a = dest.toString();
//    String b = src.toString();
//        if (a.matches(IEEE754Float.NaN_Regular) || b.matches(IEEE754Float.NaN_Regular)) {
//                return new DataType(IEEE754Float.NaN);
//                }
//                String judge=cornerCheck(addCorner,a,b);
//                if(judge!=null) return new DataType(judge);
//
//                char signalA=a.charAt(0);
//                char signalB=b.charAt(0);
//                String expA=a.substring(1,9);
//                String expB=b.substring(1,9);
//                String mantissaA=a.substring(9,32);
//                String mantissaB=b.substring(9,32);
//                char signal=' ';
//                String exp;
//                StringBuilder mantissa=new StringBuilder();
////        if(a.equals("00000000000000000000000000000000")) return new DataType(b);
////        if(b.equals("00000000000000000000000000000000")) return new DataType(a);
//                //如果有一个数是0，可以直接返回另一个数 不过这里不用特殊判断也可以 而且也忘了判断是负0的情况
//                if(expA.equals("11111111")) return new DataType(a);
//                if(expB.equals("11111111")) return new DataType(b);
//                //NaN的情况已经被排除，这里如果再出现“11111111”就是无穷大的情况了 无穷加减另一个数都是无穷
//                if(expA.equals("00000000")){
//                expA="00000001";
//                mantissaA='0'+mantissaA;
//                }
//                else mantissaA='1'+mantissaA;
//                if(expB.equals("00000000")){
//                expB="00000001";
//                mantissaB='0'+mantissaB;
//                }
//                else mantissaB='1'+mantissaB;
//                //如果阶数是“00000000”，实际上与“00000001”表示的阶数大小是一样的 但是如果不把他变成“00000001”，在阶数对齐的时候会出问题
//                mantissaA+="000";
//                mantissaB+="000";
//                //加上三位保护位
//
//                String _expB=Transformer.negation(expB);
//                int carry=1;
//                StringBuilder diff=new StringBuilder();
//                for(int i=7;i>=0;i--){
//                int x = expA.charAt(i) - '0';
//                int y = _expB.charAt(i) - '0';
//                diff.append(x ^ y ^ carry);
//                carry = x & y | x & carry | y & carry;
//                if(i==0) diff.append(1^carry);
//                //相当于在两个阶前面都加上符号位0，这样相减后最高位就是符号位，否则最高位是1的时候无法判断是表示负数还是正数（因为实际上做的是补码运算，但是原来的阶是用原码表示的）
//                }
//
//                int d=Integer.parseInt(Transformer.binaryToInt(diff.reverse().toString()));//无符号数转int
//                if(diff.charAt(0)=='1'){
//                d=d-512;
//                //如果是负数直接减去512就可以了
//                }
//
//
//                if(d>0){
//                exp=expA;
//                mantissaB=rightShift(mantissaB,d);
//                }
//                else {
//                exp=expB;
//                mantissaA=rightShift(mantissaA,-d);
//                }
//                //阶码大的那个数肯定大
//
//                //判断两者是否同号
//                boolean ifSameSignal=true;
//                if(signalA!=signalB){
//                carry=1;
//                ifSameSignal=false;
//                if(d>0) signal=signalA;
//                else if(d<0) signal=signalB;
//        else {
//        for(int i=0;i<27;i++){
//        //阶数相同 哪个尾数先出现1就是哪个数大
//        if(mantissaA.charAt(i)=='1'&&mantissaB.charAt(i)=='0'){
//        signal=signalA;
//        break;
//        }
//        else if(mantissaB.charAt(i)=='1'&&mantissaA.charAt(i)=='0'){
//        signal=signalB;
//        break;
//        }
//        if(i==26) signal='0';
//        //符号不同 阶数相同 尾数的每一位都相同 是一对相反数 得到的结果是正零
//        }
//        }
//        if(signalA=='0') mantissaB=Transformer.negation(mantissaB);
//        else mantissaA=Transformer.negation(mantissaA);
//        }
//        else{
//        signal=signalA;
//        carry=0;
//        }
//        //尾数相加
//        for(int i=26;i>=0;i--){
//        int x=mantissaA.charAt(i)-'0';
//        int y=mantissaB.charAt(i)-'0';
//        mantissa.append(x^y^carry);
//        carry=x&y|x&carry|y&carry;
//        }
//        mantissa.reverse();
//
//        if(ifSameSignal){
//        if(carry==1) {
//        if (exp.equals("11111110")) return new DataType(signal + "1111111100000000000000000000000");
//        //上溢 如果阶码已经是"11111110"了，而且最高位还有进位，那么就超出了最大可以表示的数，变成无穷了
//        else {
//        mantissa.insert(0, '1');
//        mantissa.replace(27, 28, "");
//        exp=addOne(exp);
//        }
//        }
//        else {
//        //如果最高位是0，就不断左移直到最高位是1：想要表示的是规格化数，所以首先都要想规格化数的方向化
//        while(mantissa.charAt(0)!='1'&&(!exp.equals("00000000"))){
//        mantissa.replace(0,1,"");
//        mantissa.append("0");
//        exp=subOne(exp);
//        }
//        //如果阶已经变成了“00000000”，说明已经发生了阶下溢，那么就要用非规格化数来表示 变成“00000000”后实际阶数并没有减1，所以要把尾数重新右移回去
//        if(exp.equals("00000000")){
//        mantissa.replace(26,27,"");
//        mantissa.insert(0,'0');
//        }
//        }
//        }
//        else {
//        //如果进位了 直接抹去进位就行了（正好carry并没有加上去  如果没有进位 取反加一
//        if(carry==0){
//        String temp=Transformer.negation(mantissa.toString());
//        temp=addOne(temp);
//        mantissa=new StringBuilder(temp);
//        }
//        //还是要往规格化数方向化
//        while(mantissa.charAt(0)!='1'&&(!exp.equals("00000000"))){
//        mantissa.replace(0,1,"");
//        mantissa.append("0");
//        exp=subOne(exp);
//        }
//        if(exp.equals("00000000")){
//        mantissa.replace(26,27,"");
//        mantissa.insert(0,'0');
//        }
//        }
//
//        return new DataType(round(signal,exp,mantissa.toString()));
//
//    String a = dest.toString();
//    String b = src.toString();
//    char signal=b.charAt(0);
//    String _b=(1-(signal-48))+b.substring(1,32);
//        return add(new DataType(_b),new DataType(a));