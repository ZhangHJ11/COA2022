package util;

import java.util.Objects;

public class Transformer {

    public static String intToBinary(String numStr) {
        // TODO:
//        -2147483648
        boolean isNeg;
        isNeg= numStr.charAt(0) == '-';
        String ans="";
        if(isNeg){
            numStr=numStr.substring(1);
        }
        if(numStr.equals("2147483648")){
            return "10000000000000000000000000000000";
        }
        while(ans.length()<32){
            if(Integer.parseInt(numStr)%2==1){
                ans="1"+ans;
            }else {
                ans="0"+ans;
            }
            numStr=String.valueOf(Integer.parseInt(numStr)/2);
        }
        if (isNeg){
            String ans1=ans.substring(0,ans.lastIndexOf("1"));
            String ans2=ans.substring(ans.lastIndexOf("1"));
            ans1=ans1.replaceAll("0","2");
            ans1=ans1.replaceAll("1","0");
            ans1=ans1.replaceAll("2","1");
            ans=ans1+ans2;
        }
        return ans;
    }

    public static String binaryToInt(String binStr) {
        // TODO:
        int ans=0;
        for(int i=0;i<binStr.length()-1;i++){
            if (binStr.charAt(binStr.length()-1-i)=='1'){
                ans+=Math.pow(2,i);
            }
        }
        ans-=(binStr.charAt(0)=='0')?0:Math.pow(2,binStr.length()-1);
        return String.valueOf(ans);
    }

    public static String decimalToNBCD(String decimalStr) {
        // TODO:
        boolean isNeg;
        isNeg= decimalStr.charAt(0) == '-';
        String ans="";
        if (isNeg) {
            decimalStr = decimalStr.substring(1);
        }
        for(int i=0;i<7-decimalStr.length();i++){
            ans="0000"+ans;
        }
        for(int i=0;i<decimalStr.length();i++){
            ans=ans+intToBinary(decimalStr.substring(i,i+1)).substring(28);
        }
        if(isNeg){
            ans="1101"+ans;
        }else {
            ans="1100"+ans;
        }
        return ans;
    }

    public static String NBCDToDecimal(String NBCDStr) {
        // TODO:
        String ans="";
        if(NBCDStr.substring(0, 4).equals("1101")){
            ans="-";
        }
        for (int i=0;i<7;i++){
            String tmp=NBCDStr.substring(4+4*i,8+4*i);
//            ?
            if(tmp.equals("1000")){
                ans=ans+"8";
            }else if(tmp.equals("1001")){
                ans=ans+"9";
            }else{
                ans=ans+binaryToInt(tmp);
            }
        }
        if(ans.equals("0000000") || ans.equals("-0000000")){
            return "0";
        }
        //        去掉前面的0
        if(ans.charAt(0)=='0'){
            while(ans.charAt(0)=='0'){
                ans=ans.substring(1);
            }
        }else if (ans.charAt(0)=='-'){
            while(ans.charAt(1)=='0'){
                ans="-"+ans.substring(2);
            }
        }
        return ans;
    }

    public static String floatToBinary(String floatStr) {
        // TODO:
        if (Objects.equals(floatStr, "0.0")){
            return "00000000000000000000000000000000";
        }else if (Objects.equals(floatStr, "-0.0")){
            return "10000000000000000000000000000000";
        }
        float f=Float.parseFloat(floatStr);
        if(f>=Math.pow(2,128)) return "+Inf";
        else if(f<=-Math.pow(2,128)) return "-Inf";

//        判断正负
        boolean isNeg = false;
        if(f<0){
            isNeg = true;
            f=-f;
        }

        if(f<Math.pow(2,-126)){
            String fa="";
            f*=Math.pow(2,126);
            for(int i=0;i<23;i++){
                f*=2;
                if(f>=1){
                    f-=1;
                    fa=fa+"1";
                }else {
                    fa=fa+"0";
                }
            }
            if (isNeg) return "1"+"00000000"+fa;
            else return "0"+"00000000"+fa;
        } else if (f>=Math.pow(2,-126) && f<=1){
            String fa="";
            f*=Math.pow(2,126);
            int e=0;
            while(f>=1){
                e++;
                f/=2;
            }
//            System.out.println(e);
            String ea="";
            for(int i=0;i<8;i++){
                if(e%2==1){
                    ea="1"+ea;
                }else {
                    ea="0"+ea;
                }
                e/=2;
            }
            f=f*2-1;
            for(int i=0;i<23;i++){
                f*=2;
                if(f>=1){
                    f-=1;
                    fa=fa+"1";
                }else {
                    fa=fa+"0";
                }
            }
            if (isNeg) return "1"+ea+fa;
            else return "0"+ea+fa;
        }else if (f>1){
            String fa="";
            int e=0;
            while(f>=1){
                e++;
                f/=2;
            }
            e+=126;
            String ea="";
            for(int i=0;i<8;i++){
                if(e%2==1){
                    ea="1"+ea;
                }else {
                    ea="0"+ea;
                }
                e/=2;
            }
            f=f*2-1;
            for(int i=0;i<23;i++){
                f*=2;
                if(f>=1){
                    f-=1;
                    fa=fa+"1";
                }else {
                    fa=fa+"0";
                }
            }
            if (isNeg) return "1"+ea+fa;
            else return "0"+ea+fa;
        }
        return null;
    }

    public static String binaryToFloat(String binStr) {
        // TODO:
        boolean isNeg;
        isNeg = binStr.charAt(0) == '1';

        if(!binStr.startsWith("00000000", 1) && !binStr.startsWith("11111111", 1)){
            int p=0;
            for(int i=1;i<=8;i++){
                if(binStr.charAt(i)=='1'){
                    p+=Math.pow(2,8-i);
                }
            }
            float f=0;
            for(int i=9;i<=31;i++){
                if(binStr.charAt(i)=='1'){
                    f+=Math.pow(2,8-i);
                }
            }
            float ans;
            ans=(1+f)*(float) Math.pow(2,p-127);
            if (isNeg){
                ans=-ans;
            }
//            System.out.println(p);
//            System.out.println(ans);
            return String.valueOf(ans);
        }else if (binStr.startsWith("00000000", 1)){
            float f=0;
            for(int i=9;i<=31;i++){
                if(binStr.charAt(i)=='1'){
                    f+=Math.pow(2,8-i);
                }
            }
            if (f==0){
                return "0.0";
            }
            float ans;
            ans=(0+f)*(float) Math.pow(2,-126);
            if (isNeg){
                ans=-ans;
            }
//            System.out.println(p);
//            System.out.println(ans);
            return String.valueOf(ans);
        }else if (binStr.startsWith("11111111", 1)){
            if (!binStr.startsWith("00000000000000000000000", 9)) return "NaN";
            if (isNeg) return "-Inf";
            else return "+Inf";
        }
        return null;
    }

}
